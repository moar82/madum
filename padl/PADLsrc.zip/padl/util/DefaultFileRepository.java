/*
 * (c) Copyright 2001-2004 Yann-Ga�l Gu�h�neuc,
 * University of Montr�al.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the author, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN,
 * ANY LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHOR IS ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.AccessControlException;
import java.util.ArrayList;
import java.util.List;

import padl.IFileRepository;
import util.io.NamedInputStream;
import util.io.Output;

/**
 * @author Yann-Ga�l Gu�h�neuc
 * @since  2004/07/21
 */
public class DefaultFileRepository implements IFileRepository {
	private static IFileRepository UniqueInstance;
	public static IFileRepository getInstance() {
		if (DefaultFileRepository.UniqueInstance == null) {
			DefaultFileRepository.UniqueInstance =
				new DefaultFileRepository(IFileRepository.class);
		}

		return DefaultFileRepository.UniqueInstance;
	}
	private static final void storeFiles(
		final File theCurrentDirectory,
		final List aListOfFiles) {

		final String[] files = theCurrentDirectory.list();
		for (int i = 0; i < files.length; i++) {
			final File file =
				new File(
					theCurrentDirectory.getAbsolutePath()
						+ File.separatorChar
						+ files[i]);
			if (file.isFile()) {
				try {
					aListOfFiles.add(
						new NamedInputStream(
							file.getCanonicalPath(),
							new FileInputStream(file)));
				}
				catch (final FileNotFoundException fnfe) {
					fnfe.printStackTrace(
						Output
							.getInstance()
							.errorOutput());
				}
				catch (final IOException ioe) {
					ioe.printStackTrace(
						Output
							.getInstance()
							.errorOutput());
				}
			}
			else {
				DefaultFileRepository.storeFiles(file, aListOfFiles);
			}
		}
	}
	private static final NamedInputStream[] getMetaModelFiles(final Class aClass) {
		// Yann 2004/07/28: Demo!
		// I must catch the AccessControlException
		// thrown when attempting loading anything
		// from the applet viewer.
		try {
			final String directory = util.io.File.getClassPath(aClass);

			Output.getInstance().normalOutput().print(
				"Accessing repository ");
			Output
				.getInstance()
				.normalOutput()
				.println(
				directory);

			final File directoryFile = new File(directory);
			final List listOfFiles = new ArrayList();
			DefaultFileRepository.storeFiles(directoryFile, listOfFiles);
			final NamedInputStream[] arrayOfFiles =
				new NamedInputStream[listOfFiles.size()];
			listOfFiles.toArray(arrayOfFiles);
			return arrayOfFiles;
		}
		catch (final AccessControlException ace) {
			return new NamedInputStream[0];
		}
	}

	private final NamedInputStream[] fileStreams;
	// TODO: Why is there both a Singleton and a public constructor?
	public DefaultFileRepository(final Class aClass) {
		this.fileStreams = DefaultFileRepository.getMetaModelFiles(aClass);
	}
	public NamedInputStream[] getFiles() {
		return this.fileStreams;
	}
	public String toString() {
		return this.fileStreams.length + " files in repository.";
	}
}
