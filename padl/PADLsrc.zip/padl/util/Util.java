/*
 * (c) Copyright 2001-2003 Herv� Albin-Amiot and Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * Soft-Maint S.A.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.util;

import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.File;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import padl.kernel.IAbstractModel;
import padl.kernel.IConstituent;
import padl.kernel.IEntity;
import util.io.Output;

public class Util {
	public static void addTabs(final int tab, final StringBuffer b) {
		for (int i = 0; i < tab; i++) {
			b.append("    ");
		}
	}
	public static void assertEquals(
		final int[] aFirstArray,
		final int[] aSecondArray) {

		if (aFirstArray == aSecondArray) {
			Output.getInstance().normalOutput().println(
				"Arrays are identical!");
		}
		if (aFirstArray.length != aSecondArray.length) {
			Output.getInstance().normalOutput().println(
				"Arrays have different length!");
		}

		for (int i = 0; i < aFirstArray.length; i++) {
			if (aFirstArray[i] != aSecondArray[i]) {
				Output.getInstance().errorOutput().print(
					"Arrays have different values at index ");
				Output.getInstance().errorOutput().print(i);
				Output.getInstance().errorOutput().println('!');
			}
		}
	}
	public static String capitalizeFirstLetter(final String name) {
		final StringBuffer buffer = new StringBuffer();
		buffer.append(name.substring(0, 1).toUpperCase());
		buffer.append(name.substring(1));

		return buffer.toString();
	}
	public static String computeSimpleName(final String fullyQualifiedName) {
		String simpleName = fullyQualifiedName;
		int index;

		// Yann 2006/08/03: Member class!
		// When computing the simple name of a class, I don't
		// forget that this class could be a member class and
		// that I don't want to care about its declaring class
		// (preceding the '$' sign).
		index = simpleName.lastIndexOf('$');
		if (index > 0) {
			simpleName = fullyQualifiedName.substring(index + 1);
		}
		else {
			index = simpleName.lastIndexOf('.');
			if (index > 0) {
				simpleName = simpleName.substring(index + 1);
			}
		}

		return simpleName;
	}
	private static int displayDirectoryContent(
		final int numberOfFiles,
		final String directory,
		final String fileExtension) {

		File file = new File(directory);
		int n = numberOfFiles;
		final String[] list = file.list();
		for (int i = 0; i < list.length; i++) {
			file = new File(directory + list[i]);
			if (file.isDirectory()) {
				n =
					Util.displayDirectoryContent(
						n++,
						file.getAbsolutePath() + File.separatorChar,
						fileExtension);
			}
			else {
				if (file.getName().endsWith(fileExtension)) {
					Output.getInstance().normalOutput().print("file");
					Output.getInstance().normalOutput().print(n++);
					Output.getInstance().normalOutput().print('=');
					Output.getInstance().normalOutput().println(
						file.getAbsoluteFile());
				}
			}
		}

		return n;
	}
	public static void displayDirectoryContent(
		final String directory,
		final String fileExtension) {

		Util.displayDirectoryContent(4, directory, fileExtension);
	}
	public static int getNumberOfArguments(final String methodSignature) {
		final String args =
			methodSignature.substring(methodSignature.indexOf('('));
		if (args.equals("()")) {
			return 0;
		}
		else {
			int numberOfArguments = 1;
			for (int index = 0;
				(index = args.indexOf(',', index)) > -1;
				index++, numberOfArguments++);
			return numberOfArguments;
		}
	}
	public static List getPatternProperties(final Class clazz) {
		final List roProperties = new ArrayList();
		final List rwProperties = new ArrayList();
		final List exProperties = new ArrayList();
		try {
			final PropertyDescriptor[] basicProperties =
				Introspector
					.getBeanInfo(clazz, null)
					.getPropertyDescriptors();

			for (int x = 0; x < basicProperties.length; x++) {
				final Method writeMethod =
					basicProperties[x].getWriteMethod();
				final Method readMethod = basicProperties[x].getReadMethod();

				if (readMethod != null) {
					if (writeMethod != null) {
						rwProperties.add(basicProperties[x].getName());
					}
					else {
						roProperties.add(basicProperties[x].getName());
					}
				}
			}
		}
		catch (final Exception e) {
		}

		// I look for all suitable "add" and "remove" methods.
		try {
			final Map adds = new HashMap();
			final Map removes = new HashMap();
			final Method[] methods = clazz.getMethods();
			for (int i = 0; i < methods.length; i++) {
				final Method currentMethod = methods[i];
				final int mods = currentMethod.getModifiers();
				final String currentName = currentMethod.getName();
				final Class argTypes[] = currentMethod.getParameterTypes();
				if (Modifier.isStatic(mods)
					|| !Modifier.isPublic(mods) // || argTypes.length != 1 
					|| currentMethod.getReturnType() != Void.TYPE) {

					continue; // RV: pour que Yann soit content !!!!
				}

				// Yann 2001/06/27: I check the number of arguments
				// depending on which type of method I am looking at
				// to handle correctly the add and remove methods
				// of the Fa�ade pattern.
				if (currentName.startsWith("add") && argTypes.length > 0) {
					adds.put(
						new String(
							currentName.substring(3) + ":" + argTypes[0]),
						currentMethod);
				}
				else if (
					currentName.startsWith("remove")
						&& argTypes.length == 1) {
					removes.put(
						new String(
							currentName.substring(6) + ":" + argTypes[0]),
						currentMethod);
				}
			}

			// Now I look for matching add + remove pairs.
			final Iterator keys = adds.keySet().iterator();
			while (keys.hasNext()) {
				final String addKey = (String) keys.next();
				// Skip any "add" which doesn't have a matching "remove".

				if (removes.get(addKey) != null) {
					exProperties.add(
						addKey.substring(0, addKey.indexOf(":")));

				}
			}
		}
		catch (final Exception e) {
			e.printStackTrace(Output.getInstance().errorOutput());
		}

		final List props = roProperties;
		props.addAll(rwProperties);
		props.addAll(exProperties);

		return props;
	}
	public static IConstituent[] getTypedConstituentsArray(
		final List aListOfConstituents,
		final Class aConstituentType) {

		final List list =
			Util.getTypedConstituentsList(
				aListOfConstituents,
				aConstituentType);
		final IConstituent[] constituents = new IConstituent[list.size()];
		list.toArray(constituents);

		return constituents;
	}
	public static Iterator getTypedConstituentsIterator(
		final List aListOfConstituents,
		final Class aConstituentType) {

		return Util
			.getTypedConstituentsList(aListOfConstituents, aConstituentType)
			.iterator();
	}
	private static List getTypedConstituentsList(
		final List aListOfConstituents,
		final Class aConstituentType) {

		final List list = new ArrayList();
		final Iterator iterator = aListOfConstituents.iterator();

		while (iterator.hasNext()) {
			final IConstituent constituent = (IConstituent) iterator.next();
			if (aConstituentType.isAssignableFrom(constituent.getClass())) {
				list.add(constituent);
			}
		}

		return list;
	}
	public static boolean isArray(final String typeName) {
		if (typeName.charAt(typeName.length() - 1) == ']') {
			return true;
		}
		return false;
	}
	public static boolean isArrayOrCollection(final IEntity anEntity) {
		if (Util.isArray(anEntity.getName())) {
			return true;
		}
		if (Util.isCollection(anEntity.getName())) {
			return true;
		}

		// Yann 2004/05/24: Superclasses!
		// The Misc.isArrayOrCollection() only checks the
		// direct superclass, I should certainly check the
		// complete hierarchy...
		// I check the complete inheritance tree (and
		// remove the use of reflection in isArrayOrCollection(),
		// everywhere I use this method!).
		//	try {
		//		// Yann 2003/07/24: Souvenir?
		//		// I don't remember now why I use reflection
		//		// to get the java.util.Collection class????
		//		//	final Class collectionInteface =
		//		//		Class.forName("java.util.Collection");
		//		//	final Class typeClass = Class.forName(typeName);
		//
		//		final boolean resultForDebugPurpose =
		//			Collection.class.isAssignableFrom(Class.forName(typeName));
		//		return resultForDebugPurpose;
		//	}
		//	catch (final ClassNotFoundException cnfe) {
		//	}
		//	catch (final NoClassDefFoundError ncdfe) {
		//	}

		boolean result = false;
		final Iterator iterator = anEntity.listOfInheritedActors().iterator();
		while (iterator.hasNext() && !result) {
			result = Util.isArrayOrCollection((IEntity) iterator.next());
		}
		return result;
	}
	public static boolean isArrayOrCollection(final String typeName) {
		if (Util.isArray(typeName)) {
			return true;
		}
		if (Util.isCollection(typeName)) {
			return true;
		}
		return false;
	}
	public static boolean isCollection(final String aTypeName) {
		return aTypeName.equals("java.util.Collection")
			|| aTypeName.equals("java.util.AbstractList")
			|| aTypeName.equals("java.util.ArrayList")
			|| aTypeName.equals("java.util.LinkedList")
			|| aTypeName.equals("java.util.Vector")
			|| aTypeName.equals("java.util.Stack")
			|| aTypeName.equals("java.util.AbstractSequentialList")
			|| aTypeName.equals("java.util.List")
			|| aTypeName.equals("java.util.Set")
			|| aTypeName.equals("java.util.AbstractSet")
			|| aTypeName.equals("java.util.HashSet")
			|| aTypeName.equals("java.util.LinkedHashSet")
			|| aTypeName.equals("java.util.TreeSet")
			|| aTypeName.equals("java.util.SortedSet");
	}
	
	public static boolean isClassException(final String aClassName) {
		return aClassName.endsWith("Exception")
		|| (aClassName.indexOf("Exception")!=-1);
	}
	
	public static boolean isMethodFromObject(final String aMethodName) {
		return aMethodName.equals("clone")
			|| aMethodName.equals("equals")
			|| aMethodName.equals("finalize")
			|| aMethodName.equals("hashCode")
			|| aMethodName.equals("toString");
	}
	public static boolean isObjectModelRoot(final String aTypeName) {
		return aTypeName.equals("java.lang.Object");
	}
	public static boolean isPrimtiveType(final String aTypeName) {
		return aTypeName.equals("boolean")
			|| aTypeName.equals("byte")
			|| aTypeName.equals("char")
			|| aTypeName.equals("short")
			|| aTypeName.equals("double")
			|| aTypeName.equals("float")
			|| aTypeName.equals("int")
			|| aTypeName.equals("long")
			|| aTypeName.equals("boolean[]")
			|| aTypeName.equals("byte[]")
			|| aTypeName.equals("char[]")
			|| aTypeName.equals("short[]")
			|| aTypeName.equals("double[]")
			|| aTypeName.equals("float[]")
			|| aTypeName.equals("int[]")
			|| aTypeName.equals("long[]")
			|| aTypeName.equals("void")
			|| aTypeName.indexOf('[') > -1;
	}
	public static String minimizeFirstLetter(final String name) {
		final StringBuffer buffer = new StringBuffer();
		buffer.append(name.substring(0, 1).toLowerCase());
		buffer.append(name.substring(1));

		return buffer.toString();
	}
	public static String stripAndCapQualifiedName(final String qualifiedName) {
		final StringBuffer buffer = new StringBuffer();
		boolean previousCharWhitespace = false;
		for (int i = 0; i < qualifiedName.length(); i++) {
			final char c = qualifiedName.charAt(i);
			// Yann 2002/12/17: Inner classes!
			// I must remove the $ sign from names
			// coming from inner classes!
			if (c != '.' && c != '$') {
				if (previousCharWhitespace) {
					buffer.append(Character.toUpperCase(c));
					previousCharWhitespace = false;
				}
				else {
					buffer.append(c);
				}
			}
			else {
				previousCharWhitespace = true;
			}
		}

		return buffer.toString();
	}
	private Util() {
	}
	public static String computeFullyQualifiedName(
		final IAbstractModel anAbstractModel,
		final IEntity anEntity) {

		Iterator iterator =
			anAbstractModel.getIteratorOnActors(IEntity.class);
		while (iterator.hasNext()) {
			final IEntity entity = (IEntity) iterator.next();
			if (entity.equals(anEntity)) {
				return entity.getName();
			}
			else {
				final String fullyQualifiedName =
					Util.computeFullyQualifiedName(
						entity,
						anEntity,
						entity.getName());
				if (!fullyQualifiedName.equals("")) {
					return fullyQualifiedName;
				}
			}
		}

		return "";
	}
	private static String computeFullyQualifiedName(
		final IEntity anEnclosingEntity,
		final IEntity anEntity,
		final String aFullyQualifiedName) {

		final Iterator iterator =
			anEnclosingEntity.getIteratorOnActors(IEntity.class);
		while (iterator.hasNext()) {
			final IEntity entity = (IEntity) iterator.next();
			final String qualifiedName =
				aFullyQualifiedName + '.' + entity.getName();

			if (entity.equals(anEntity)) {
				return qualifiedName;
			}
			else {
				return Util.computeFullyQualifiedName(
					entity,
					anEntity,
					qualifiedName);
			}
		}

		return "";
	}
}