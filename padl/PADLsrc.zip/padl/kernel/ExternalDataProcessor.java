/*
 * (c) Copyright 2000-2002 Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes and Object Technology International, Inc.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * Yann-Ga�l Gu�h�neuc, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YANN-GAEL GUEHENEUC IS ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel;

import java.util.Iterator;
import java.util.Properties;
import java.util.StringTokenizer;

import padl.kernel.exception.ModelDeclarationException;
import util.io.Output;

/**
 * @author Yann-Ga�l Gu�h�neuc
 * @since  2002/10/08
 */
public final class ExternalDataProcessor {
	private static void addAggregationRelationship(
		final IAbstractModel anAbstractModel,
		final IEntity anOriginEntity,
		final String aRelationshipName,
		final IEntity aTargetEntity,
		final int aCardinality) {

		try {
			final IAggregation aggregation =
				anAbstractModel.getFactory().createAggregationRelationship(
					aRelationshipName,
					aTargetEntity,
					aCardinality);
			anOriginEntity.addActor(aggregation);
		}
		catch (final ModelDeclarationException pde) {
			pde.printStackTrace(Output.getInstance().errorOutput());
		}
	}
	private static void addCompositionRelationship(
		final IAbstractModel anAbstractModel,
		final IEntity anOriginEntity,
		final String aRelationshipName,
		final IEntity aTargetEntity,
		final int aCardinality) {

		try {
			final IComposition composition =
				anAbstractModel.getFactory().createCompositionRelationship(
					aRelationshipName,
					aTargetEntity,
					aCardinality);
			anOriginEntity.addActor(composition);
		}
		catch (final ModelDeclarationException pde) {
			pde.printStackTrace(Output.getInstance().errorOutput());
		}
	}
	private static void convertAggregationInComposition(
		final IAbstractModel anAbstractModel,
		final IEntity anOriginEntity,
		final IEntity aTargetEntity) {

		final Iterator iterator =
			anOriginEntity.getIteratorOnConcurrentActors();
		while (iterator.hasNext()) {
			final IElement element = (IElement) iterator.next();

			if (element instanceof IAssociation) {
				final IAssociation association = (IAssociation) element;
				if (association
					.getTargetActor()
					.isAboveInHierarchy(aTargetEntity)) {

					anOriginEntity.removeActorFromID(association.getID());
					try {
						if (association instanceof IContainerAggregation) {
							anOriginEntity.addActor(
								anAbstractModel
									.getFactory()
									.createContainerCompositionRelationship(
									association));
						}
						else if (association instanceof IAggregation) {
							anOriginEntity.addActor(
								anAbstractModel
									.getFactory()
									.createCompositionRelationship(
									association));
						}
					}
					catch (final ModelDeclarationException pde) {
						pde.printStackTrace(
							Output.getInstance().errorOutput());
					}
				}
			}
		}
	}
	public static void process(
		final Properties someProperties,
		final IAbstractModel anAbstractModel) {

		final Iterator iterator = someProperties.keySet().iterator();
		while (iterator.hasNext()) {
			final String key = (String) iterator.next();
			if (key.startsWith("Relation")) {
				final String command = someProperties.getProperty(key);
				final int parenthesisIndex = command.indexOf('(');
				final String name = command.substring(0, parenthesisIndex);
				final String arguments =
					command.substring(
						parenthesisIndex + 1,
						command.length() - 1);

				if (name.equals("addAggregationRelationship")
					|| name.equals("addCompositionRelationship")) {

					final StringTokenizer tokenizer =
						new StringTokenizer(arguments, "(,)");
					final IEntity originEntity =
						(IEntity) anAbstractModel.getActorFromName(
							tokenizer.nextToken().trim());
					final String relationshipName =
						tokenizer.nextToken().trim();
					final IEntity targetEntity =
						(IEntity) anAbstractModel.getActorFromName(
							tokenizer.nextToken().trim());
					final Integer cardinality =
						new Integer(tokenizer.nextToken().trim());

					if (originEntity != null && targetEntity != null) {
						if (name.equals("addAggregationRelationship")) {
							ExternalDataProcessor.addAggregationRelationship(
								anAbstractModel,
								originEntity,
								relationshipName,
								targetEntity,
								cardinality.intValue());
						}
						else if (name.equals("addCompositionRelationship")) {
							ExternalDataProcessor.addCompositionRelationship(
								anAbstractModel,
								originEntity,
								relationshipName,
								targetEntity,
								cardinality.intValue());
						}
					}
				}
				else if (name.equals("convertAggregationInComposition")) {
					final StringTokenizer tokenizer =
						new StringTokenizer(arguments, ",");
					final IEntity originEntity =
						(IEntity) anAbstractModel.getActorFromName(
							tokenizer.nextToken().trim());
					final IEntity targetEntity =
						(IEntity) anAbstractModel.getActorFromName(
							tokenizer.nextToken().trim());

					if (originEntity != null && targetEntity != null) {
						ExternalDataProcessor
							.convertAggregationInComposition(
							anAbstractModel,
							originEntity,
							targetEntity);
					}
				}
			}
		}
	}
}
