/*
 * (c) Copyright 2001-2003 Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN,
 * ANY LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel;

import java.util.Iterator;
import java.util.List;

import padl.kernel.exception.ModelDeclarationException;

/**
 * @author Yann-Ga�l Gu�h�neuc
 */
public interface IContainer {
	/**
	 * The implementation must ensure that actors
	 * are ordered in the same way across platforms.
	 * (Yann 2004/04/09)
	 */
	void addActor(final IConstituent aConstituent)
		throws ModelDeclarationException;
	boolean doesContainActorWithID(final String anID);
	boolean doesContainActorWithName(final String aName);
	IConstituent getActorFromID(final String anID);
	IConstituent getActorFromName(final String aName);
	Iterator getIteratorOnActors();
	Iterator getIteratorOnActors(final java.lang.Class aConstituentType);
	Iterator getIteratorOnConcurrentActors();
	Iterator getIteratorOnConcurrentActors(
		final java.lang.Class aConstituentType);
	int getNumberOfActors();
	int getNumberOfActors(final java.lang.Class aConstituentType);
	int getUniqueID();
	/**
	 * The implementation must ensure that actors
	 * are ordered in the same way across platforms.
	 * (Yann 2004/04/09)
	 * 
	 * @deprecated This method is dangerous because it exposes the
	 * inner working of all the constituents that are able to contains
	 * other constituents. Thus, it is now replaced with the two
	 * getIterator() and getIterator(Class aConstituentType) methods
	 * (and related methods).
	 */
	List listOfActors();
	void removeActorFromID(final String anID);
	void removeAllActors();
}
