/*
 * (c) Copyright 2001, 2002 Herv� Albin-Amiot and Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * Soft-Maint S.A.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import padl.kernel.Constants;
import padl.kernel.IConstituent;
import padl.kernel.IVisitor;
import padl.kernel.exception.ModelDeclarationException;
import padl.util.Util;
import util.io.Output;
import util.lang.Modifier;
import util.multilingual.MultilingualManager;

import com.ibm.toad.cfparse.utils.Access;

// TODO: Should we provide to people extending PADL some default
// implementation of the different Constituent of the meta-model?
// Maybe class "Constituent" could be public, or classes "Elements"
// and "Entities"?
abstract class Constituent
	extends AbstractContainer
	implements IConstituent {

	// Yann 2004/04/09: Why "extends AbstractContainer"?
	// From the point of view of the model (defined by the
	// interfaces in the kernel), only certain constituent
	// may hold other constituent (by implementing IContainer).
	// From the point of view of the implementation and to
	// avoid duplication, any constituent may hold other
	// constituent. This is not a problem because a model 
	// can only be manipulated through the interfaces.
	private String actorID;
	private Constituent clone;
	private List clonedBoundEventList = new ArrayList(0);
	private List clonedVetoEventList = new ArrayList(0);
	private String[] codeLines;
	private String comment;
	private String displayName;
	private String name;
	private int visibility = Access.ACC_PUBLIC;
	private int weight = Constants.MANDATORY;

	public Constituent(final String anActorID) {
		if (anActorID == null) {
			throw new RuntimeException(
				new ModelDeclarationException(
					MultilingualManager.getString(
						"ACTOR_ID_NULL",
						Constituent.class)));
		}
		this.actorID = anActorID;
		this.setName(anActorID);
	}

	public void accept(final IVisitor visitor) {
		this.accept(visitor, "visit");
	}
	protected void accept(final IVisitor visitor, final String methodName) {
		final String acceptMethodName =
			this.getClass().getName().replaceAll(".impl.", ".I");
		try {
			// Yann 2003/12/05: Interfaces!
			// I must match a class a the kernel to the 
			// corresponding interface: 
			//     padl.kernel.kernel.impl.Association
			// ->
			//     padl.kernel.IAssociation
			final java.lang.Class[] argument =
				new java.lang.Class[] {
					 java.lang.Class.forName(acceptMethodName)};
			final Method method =
				visitor.getClass().getMethod(methodName, argument);
			method.invoke(visitor, new Object[] { this });
		}
		catch (final Exception e) {
			// Yann 2004/04/10: New constituents!
			// In case I add new constituent and forget to update
			// the method in the IVisitor interface, I foward such
			// exceptions (to fail the appropriate tests).
			System.err.print(
				MultilingualManager.getString(
					"Exception_ACCEPT_METHOD",
					Constituent.class,
					new Object[] { methodName, acceptMethodName }));
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
	public void endCloneSession() {
		this.clone = null;
		this.clonedBoundEventList.clear();
		this.clonedVetoEventList.clear();
	}
	public boolean equals(final Object obj) {
		if (!(obj instanceof IConstituent)) {
			return false;
		}
		return this.getID().equals(((IConstituent) obj).getID());
	}
	public IConstituent getClone() {
		return this.clone;
	}
	public String[] getCodeLines() {
		return this.codeLines;
	}
	public String getComment() {
		return this.comment;
	}
	public String getDisplayName() {
		return this.displayName;
	}
	public String getID() {
		return this.actorID;
	}
	public String getName() {
		return this.name;
	}
	public int getVisibility() {
		return this.visibility;
	}
	public int getWeight() {
		return this.weight;
	}
	public int hashCode() {
		return this.getID().hashCode();
	}
	public boolean isAbstract() {
		return Access.isAbstract(this.visibility);
	}
	public boolean isFinal() {
		return Access.isFinal(this.visibility);
	}
	public boolean isPrivate() {
		return Access.isPrivate(this.visibility);
	}
	public boolean isProtected() {
		return Access.isProtected(this.visibility);
	}
	public boolean isPublic() {
		return Access.isPublic(this.visibility);
	}
	public boolean isStatic() {
		return Access.isStatic(this.visibility);
	}

	/**
	 * This methods is used by the clone protocol.
	 */
	public void performCloneSession() {
	}
	public void resetCodeLines() throws ModelDeclarationException {
		this.setCodeLines("");
	}
	public void setAbstract(final boolean aBoolean)
		throws ModelDeclarationException {

		this.setVisibility(
			aBoolean
				? (this.getVisibility() | Access.ACC_ABSTRACT)
				: (this.getVisibility() & ~Access.ACC_ABSTRACT));
	}
	public void setCodeLines(final String code)
		throws ModelDeclarationException {

		this.setCodeLines(new String[] { code });
	}
	public void setCodeLines(String[] code)
		throws ModelDeclarationException {

		if (this.isAbstract()) {
			throw new ModelDeclarationException(
				MultilingualManager.getString(
					"ELEM_CODE_DEF",
					Constituent.class));
		}
		this.codeLines = code;
	}
	public void setComment(final String aComment) {
		this.comment = aComment;
	}
	public void setDisplayName(final String aName) {
		this.displayName = aName;
	}
	public void setFinal(final boolean aBoolean) {
		try {
			this.setVisibility(
				aBoolean
					? (this.getVisibility() | Access.ACC_FINAL)
					: (this.getVisibility() & ~Access.ACC_FINAL));
		}
		catch (final ModelDeclarationException e) {
			// No error can occur.
		}
	}
	protected void setID(final String anID) {
		this.actorID = anID;
	}
	public void setName(final String aName) {
		this.name = aName;
		this.setDisplayName(aName);
	}
	public void setPrivate(final boolean aBoolean) {
		try {
			this.setVisibility(
				aBoolean
					? ((this.getVisibility() | Access.ACC_PRIVATE)
						& ~(Access.ACC_PUBLIC | Access.ACC_PROTECTED))
					: (this.getVisibility() & ~Access.ACC_PRIVATE));
		}
		catch (final ModelDeclarationException e) {
			// No error can occur.
		}
	}
	public void setProtected(final boolean aBoolean) {
		try {
			this.setVisibility(
				aBoolean
					? ((this.getVisibility() | Access.ACC_PROTECTED)
						& ~(Access.ACC_PUBLIC | Access.ACC_PRIVATE))
					: (this.getVisibility() & ~Access.ACC_PROTECTED));
		}
		catch (final ModelDeclarationException e) {
			// No error can occur.
		}
	}
	public void setPublic(final boolean aBoolean) {
		try {
			this.setVisibility(
				aBoolean
					? ((this.getVisibility() | Access.ACC_PUBLIC)
						& ~(Access.ACC_PRIVATE | Access.ACC_PROTECTED))
					: (this.getVisibility() & ~Access.ACC_PUBLIC));
		}
		catch (final ModelDeclarationException e) {
			// No error can occur.
		}
	}
	public void setStatic(final boolean aBoolean) {
		try {
			this.setVisibility(
				aBoolean
					? (this.getVisibility() | Access.ACC_STATIC)
					: (this.getVisibility() & ~Access.ACC_STATIC));
		}
		catch (final ModelDeclarationException e) {
			// No error can occur.
		}
	}
	public void setVisibility(final int visibility)
		throws ModelDeclarationException {

		if (this.getCodeLines() != null && Access.isAbstract(visibility)) {
			// Why test getCodeLines() != null here ?
			throw new ModelDeclarationException(
				MultilingualManager.getString(
					"ELEM_ABSTRACT",
					Constituent.class));
		}
		this.visibility = visibility;
	}
	public void setWeight(final int weight) {
		this.weight = weight;
	}
	/**
	 * This method performs a shallow copy.
	 */
	public void startCloneSession() {
		try {
			final Constituent tmpObject = (Constituent) super.clone();
			this.clone = tmpObject;
			tmpObject.clone = null;
		}
		catch (final CloneNotSupportedException cnse) {
			cnse.printStackTrace(Output.getInstance().errorOutput());
		}
	}
	public String toString() {
		return this.toString(0);
	}
	public String toString(final int tab) {
		final StringBuffer codeEq = new StringBuffer();
		Util.addTabs(tab, codeEq);
		if (this.getComment() != null) {
			codeEq.append("/* ");
			codeEq.append(this.getComment());
			codeEq.append(" */\n");
			Util.addTabs(tab, codeEq);
		}
		codeEq.append(Modifier.toString(this.getVisibility()));
		return codeEq.toString();
	}
}
