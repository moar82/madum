/*
 * (c) Copyright 2001-2003 Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN,
 * ANY LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

import java.util.Iterator;

import padl.kernel.IConstituent;
import padl.kernel.IDesignMotif;
import padl.kernel.IDetector;
import padl.kernel.IEntity;
import padl.kernel.IFactory;
import padl.kernel.IGenerator;
import padl.kernel.IWalker;
import padl.kernel.exception.ModelDeclarationException;
import util.io.Output;
import util.multilingual.MultilingualManager;

public abstract class MotifModel
	extends Constituent
	implements IDesignMotif {

	private IDetector defaultDetector;
	private IFactory factory;

	public MotifModel(final String actorID) {
		super(actorID);
	}
	public final void addActor(final IConstituent constituent)
		throws ModelDeclarationException {

		if (constituent instanceof IEntity) {
			super.addActor((Entity) constituent);
		}
		else {
			throw new ModelDeclarationException(
				MultilingualManager.getString(
					"ENT_ADD_MODEL",
					MotifModel.class));
		}
	}
	public final String generate(final IGenerator builder) {
		builder.open(this);

		final Iterator iterator = this.getIteratorOnActors();
		while (iterator.hasNext()) {
			((IConstituent) iterator.next()).accept(builder);
		}

		builder.close(this);
		return builder.getCode();
	}
	public final Object clone() throws CloneNotSupportedException {
		// Yann: Here is the new clone protocole. This is subject
		// to discussion!! The idea is that a pattern may be cloned,
		// but a constituent of a pattern (Element or Entity) may
		// not be cloned individually, it does not make sense to clone
		// a Method if the rest of the pattern is not cloned to. I
		// believe this is actually a risk: to be able to clone a single
		// constituent on an individual basis may prove to create
		// duplicates with references on current objects...
		// Thus, only the AbstractLevelModel class implements the
		// Cloneable interface.
		// The constituents of the pattern implements the
		// ICloneable interface. This pattern provides
		// three methods:
		// * startCloneSession() is somewhat equivallent to a shallow
		//   copy of the constituent. After this protocol is executed,
		//   it is guaranteed that all constituents have been
		//   shallow-copied. No assumption is made about the link among
		//   constituents.
		// * performCloneSession() updates the links among constituents,
		//   using the isCloned() and getClone() methods. After this
		//   protocol is executed, it is guarenteed that all the links
		//   have been updated, somewhat like a deep copy;
		// * endCloneSession() finished the updates and cleans the possible
		//   temporary values, mainly it sets to null all the "clone"
		//   instance variable.

		final MotifModel clonedPattern = (MotifModel) super.clone();
		// Yann 2002/04/08: Clone!
		// The cloned pattern must have its own instance
		// of class ArrayList for the list or PEntities.
		clonedPattern.resetListOfActors();

		// First, I make a shallow copy of all the entities.
		Iterator iterator = this.getIteratorOnActors();
		while (iterator.hasNext()) {
			final IConstituent constituent = (IConstituent) iterator.next();
			constituent.startCloneSession();
			try {
				clonedPattern.addActor(constituent.getClone());
			}
			catch (final ModelDeclarationException pde) {
				pde.printStackTrace(Output.getInstance().errorOutput());
			}
		}

		// Second, I update the links among entities (deep copy).
		iterator = this.getIteratorOnActors();
		while (iterator.hasNext()) {
			((IConstituent) iterator.next()).performCloneSession();
		}

		// Finally, I clean up all temporary instance variable.
		iterator = this.getIteratorOnActors();
		while (iterator.hasNext()) {
			((IConstituent) iterator.next()).endCloneSession();
		}

		return clonedPattern;
	}
	/**
	 * This method returns a list of hashtable. Each hashtable represents a solution
	 * found. A solution is a set of keys representing the entities, associated to the
	 * real entities found in the given source code.
	 */
	//	public List compare(final IAbstractModel model) {
	//		final List solutions = new ArrayList();
	//		Map partialSolutions;
	//
	//		if (this.getDetector() == null) {
	//			OutputManager.getCurrentOutputManager().getErrorOutput().println(
	//				MultilanguageManager.getStrResource(
	//					"Err_INIT_ALMD",
	//					resourceBaseName
	//				)
	//			);
	//			return new ArrayList();
	//		}
	//		this.getDetector().setPattern(this);
	//		partialSolutions =
	//			((Detector) this.getDetector()).buildPartialSolution(model);
	//		if (partialSolutions.size() > 0) {
	//			partialSolutions =
	//				((Detector) this.getDetector()).applyCriterias(
	//					partialSolutions,
	//					Detector.AllCriterias);
	//			if (partialSolutions.size() > 0) {
	//				solutions.add(partialSolutions);
	//			}
	//		}
	//		return solutions;
	//	}
	public abstract int getClassification();
	public final IDetector getDetector() {
		return this.defaultDetector;
	}
	public IFactory getFactory() {
		return this.factory;
	}
	public abstract String getIdiom();
	public abstract String getIntent();
	public final void setDetector(final IDetector aPatternDetector) {
		this.defaultDetector = aPatternDetector;
	}
	public void setFactory(final IFactory aFactory) {
		this.factory = aFactory;
	}
	public final Object walk(final IWalker walker) {
		walker.open(this);
		final Iterator iterator = this.getIteratorOnActors();
		while (iterator.hasNext()) {
			((IConstituent) iterator.next()).accept(walker);
		}

		walker.close(this);
		return walker.getResult();
	}
}
