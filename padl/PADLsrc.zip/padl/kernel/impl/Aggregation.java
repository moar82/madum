/*
 * (c) Copyright 2001, 2002 Herv� Albin-Amiot and Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * Soft-Maint S.A.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

import padl.kernel.IAggregation;
import padl.kernel.IElementMarker;
import padl.kernel.IEntity;
import padl.kernel.IField;
import padl.kernel.IMethod;
import padl.kernel.exception.ModelDeclarationException;

class Aggregation
	extends Association
	implements IElementMarker, IAggregation {

	public static String getLogo() {
		return "[]-->";
	}
	public Aggregation(final Association pAssociation)
		throws ModelDeclarationException {

		this(
			pAssociation.getID(),
			pAssociation.getTargetActor(),
			pAssociation.getCardinality());
	}
	public Aggregation(
		final String anActorID,
		final IEntity aTargetEntity,
		final int cardinality)
		throws ModelDeclarationException {

		super(anActorID, aTargetEntity, cardinality);
	}
	public Aggregation(
		final String anActorID,
		final IEntity aTargetEntity,
		final int cardinality,
		final IField originField,
		final IMethod originGetterMethod,
		final IMethod originSetterMethod)
		throws ModelDeclarationException {

		super(anActorID, aTargetEntity, cardinality);
	}
}