/*
 * (c) Copyright 2001-2003 Yann-Ga�l Gu�h�neuc,
 * �cole des Mines de Nantes and Object Technology International, Inc.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the author, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN,
 * ANY LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHOR IS ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

import padl.kernel.IAggregation;
import padl.kernel.IAssociation;
import padl.kernel.IClass;
import padl.kernel.ICodeLevelModel;
import padl.kernel.IComposition;
import padl.kernel.IConstructor;
import padl.kernel.IContainerAggregation;
import padl.kernel.IContainerComposition;
import padl.kernel.ICreation;
import padl.kernel.IDelegatingMethod;
import padl.kernel.IDesignLevelModel;
import padl.kernel.IEntity;
import padl.kernel.IFactory;
import padl.kernel.IField;
import padl.kernel.IGetter;
import padl.kernel.IGhost;
import padl.kernel.IIdiomLevelModel;
import padl.kernel.IInterface;
import padl.kernel.IMemberClass;
import padl.kernel.IMemberGhost;
import padl.kernel.IMemberInterface;
import padl.kernel.IMethod;
import padl.kernel.IMethodInvocation;
import padl.kernel.IPackage;
import padl.kernel.IParameter;
import padl.kernel.ISetter;
import padl.kernel.IUseRelationship;
import padl.kernel.exception.ModelDeclarationException;
import padl.util.Util;
import util.multilingual.MultilingualManager;

/**
 * @author Yann-Ga�l Gu�h�neuc
 */
public class Factory implements IFactory {
	private static Factory UniqueInstance;
	public static Factory getInstance() {
		if (Factory.UniqueInstance == null) {
			Factory.UniqueInstance = new Factory();
		}
		return Factory.UniqueInstance;
	}

	protected Factory() {
	}
	public IAggregation createAggregationRelationship(
		final String aName,
		final IEntity aTargetEntity,
		final int aCardinality)
		throws ModelDeclarationException {

		return new Aggregation(aName, aTargetEntity, aCardinality);
	}
	public IAssociation createAssociationRelationship(
		final String anActorID,
		final IEntity aTargetEntity,
		final int aCardinality)
		throws ModelDeclarationException {

		return new Association(anActorID, aTargetEntity, aCardinality);
	}
	public IClass createClass(final String aName)
		throws ModelDeclarationException {

		return new Class(aName);
	}
	public ICodeLevelModel createCodeLevelModel(final String aName) {
		final ICodeLevelModel codeLevelModel = new CodeLevelModel(aName);
		codeLevelModel.setFactory(this);
		return codeLevelModel;
	}
	public IComposition createCompositionRelationship(final IAssociation anAssociation)
		throws ModelDeclarationException {
		return new Composition(anAssociation);
	}
	public IComposition createCompositionRelationship(
		final String anActorID,
		final IEntity aTargetEntity,
		final int aCardinality)
		throws ModelDeclarationException {

		return new Composition(anActorID, aTargetEntity, aCardinality);
	}
	public IConstructor createConstructor(final String aName)
		throws ModelDeclarationException {

		return new Constructor(aName);
	}
	public IContainerAggregation createContainerAggregationRelationship(
		final String anActorID,
		final IEntity aTargetEntity,
		final int aCardinality)
		throws ModelDeclarationException {

		return new ContainerAggregation(
			anActorID,
			aTargetEntity,
			aCardinality);
	}
	public IContainerComposition createContainerCompositionRelationship(final IAssociation anAssociation)
		throws ModelDeclarationException {

		return new ContainerComposition(anAssociation);
	}
	public IContainerComposition createContainerCompositionRelationship(
		final String anActorID,
		final IEntity aTargetEntity,
		final int aCardinality)
		throws ModelDeclarationException {

		return new ContainerComposition(
			anActorID,
			aTargetEntity,
			aCardinality);
	}
	public ICreation createCreationRelationship(
		final String anActorID,
		final IEntity aTargetEntity,
		final int aCardinality)
		throws ModelDeclarationException {

		return new Creation(anActorID, aTargetEntity, aCardinality);
	}
	public IDelegatingMethod createDelegatingMethod(
		final String aName,
		final IAssociation aTargetAssociation)
		throws ModelDeclarationException {

		return new DelegatingMethod(aName, aTargetAssociation);
	}
	public IDelegatingMethod createDelegatingMethod(
		final String aName,
		final IAssociation aTargetAssociation,
		final IMethod aSupportMethod)
		throws ModelDeclarationException {

		return new DelegatingMethod(
			aName,
			aTargetAssociation,
			aSupportMethod);
	}
	public IDesignLevelModel createDesignLevelModel(final String aName) {
		final IDesignLevelModel designLevelModel =
			new DesignLevelModel(aName);
		designLevelModel.setFactory(this);
		return designLevelModel;
	}
	public IField createField(
		final String aName,
		final String aType,
		final int aCardinality)
		throws ModelDeclarationException {

		return new Field(aName, aType, aCardinality);
	}
	public IGetter createGetter(final IMethod aMethod)
		throws ModelDeclarationException {

		return new Getter(aMethod);
	}
	public IGetter createGetter(final String aName)
		throws ModelDeclarationException {

		return new Getter(aName);
	}
	public IGhost createGhost(final String aName)
		throws ModelDeclarationException {

		String name = aName;
		// Yann 2004/01/23: Ghost, arrays, and primitive types.
		// I make sure before creating a ghost that it is not
		// an array or a primitive type.
		final int bracketIndex = name.indexOf('[');
		if (bracketIndex > -1) {
			name = name.substring(0, bracketIndex);
		}
		if (Util.isPrimtiveType(name)) {
			throw new ModelDeclarationException(
				MultilingualManager.getString("ADD", Factory.class));
		}

		return new Ghost(name);
	}
	public IIdiomLevelModel createIdiomLevelModel(final String aName) {
		final IIdiomLevelModel idiomLevelModel = new IdiomLevelModel(aName);
		idiomLevelModel.setFactory(this);
		return idiomLevelModel;
	}
	public IInterface createInterface(final String aName)
		throws ModelDeclarationException {

		return new Interface(aName);
	}
	public IMemberClass createMemberClass(final String aName)
		throws ModelDeclarationException {

		return new MemberClass(aName);
	}
	public IMemberGhost createMemberGhost(final String aName)
		throws ModelDeclarationException {

		return new MemberGhost(aName);
	}
	public IMemberInterface createMemberInterface(final String aName)
		throws ModelDeclarationException {

		return new MemberInterface(aName);
	}
	public IMethod createMethod(final String aName)
		throws ModelDeclarationException {

		return new Method(aName);
	}
	public IMethodInvocation createMethodInvocation(
		final int type,
		final int cardinality,
		final int visibility,
		final IEntity targetEntity)
		throws ModelDeclarationException {

		return new MethodInvocation(
			type,
			cardinality,
			visibility,
			targetEntity);
	}
	public IMethodInvocation createMethodInvocation(
		final int type,
		final int cardinality,
		final int visibility,
		final IEntity targetEntity,
		final IEntity entityDeclaringField)
		throws ModelDeclarationException {

		return new MethodInvocation(
			type,
			cardinality,
			visibility,
			targetEntity,
			entityDeclaringField);
	}
	public IPackage createPackage(final String aName)
		throws ModelDeclarationException {

		return new Package(aName);
	}
	public IParameter createParameter(final String aType)
		throws ModelDeclarationException {

		return new Parameter(aType);
	}
	public IParameter createParameter(final String aName, final String aType)
		throws ModelDeclarationException {

		return new Parameter(aName, aType);
	}
	public ISetter createSetter(final IMethod aMethod)
		throws ModelDeclarationException {

		return new Setter(aMethod);
	}
	public ISetter createSetter(final String aName)
		throws ModelDeclarationException {

		return new Setter(aName);
	}
	//	public IParameter createParameter(
	//		final int aPosition,
	//		final String aName,
	//		final String aType)
	//		throws ModelDeclarationException {
	//
	//		return new Parameter(aPosition, aName, aType);
	//	}
	public IUseRelationship createUseRelationship(
		final String anActorID,
		final IEntity aTargetEntity,
		final int aCardinality)
		throws ModelDeclarationException {

		return new UseRelationship(anActorID, aTargetEntity, aCardinality);
	}
}
