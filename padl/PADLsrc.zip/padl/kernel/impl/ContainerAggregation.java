/*
 * (c) Copyright 2001, 2002 Herv� Albin-Amiot and Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * Soft-Maint S.A.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import padl.kernel.IConstituent;
import padl.kernel.IContainerAggregation;
import padl.kernel.IElementMarker;
import padl.kernel.IEntity;
import padl.kernel.exception.ModelDeclarationException;
import padl.util.Util;
import util.io.Output;
import util.lang.Modifier;
import util.multilingual.MultilingualManager;

class ContainerAggregation
	extends Association
	implements IElementMarker, IContainerAggregation {

	// Only used if concrete.
	private List associationElements;

	// Yann 2002/07/31: Start small...
	// For the moment, an aggregation only knows about its field
	// and the getter and setter methods:
	//     "get" / "set" OR "remove" / "add".
	// We leave for later to manage a "get" method in case of cardinality
	// greater than one...
	// However, for updating purpose (cloning...), I must record if
	// this is an aggregation created from void or not.
	private final boolean isFromVoid;
	private Field originField;
	private Method originGetterMethod;
	private Method originSetterMethod;

	public ContainerAggregation(final Association pAssociation)
		throws ModelDeclarationException {

		this(
			pAssociation.getID(),
			pAssociation.getTargetActor(),
			pAssociation.getCardinality());
	}
	public ContainerAggregation(
		final String anActorID,
		final IEntity aTargetEntity,
		final int cardinality)
		throws ModelDeclarationException {

		super(anActorID, aTargetEntity, cardinality);

		this.isFromVoid = true;

		this.updateAssociation();
	}

	// Yann 2003/12/15: Herv�!
	// This is legacy code from Herv�! Pay it most respect!
	// Meawhile, study if we can safely remove it... :-)
	//	public ContainerAggregation(
	//		final String anActorID,
	//		final IEntity aTargetEntity,
	//		final int cardinality,
	//		final Field originField,
	//		final Method originGetterMethod,
	//		final Method originSetterMethod)
	//		throws ModelDeclarationException {
	//	
	//		super(anActorID, aTargetEntity, cardinality);
	//	
	//		this.isFromVoid = false;
	//	
	//		if (this.originField == null
	//			|| this.originGetterMethod == null
	//			|| this.originSetterMethod == null) {
	//	
	//			throw new ModelDeclarationException("An instance of Aggregation must have origin field and methods.");
	//		}
	//		this.originField = originField;
	//		this.originGetterMethod = originGetterMethod;
	//		this.originSetterMethod = originSetterMethod;
	//	
	//		if (!this.isAbstract()) {
	//			this.associationElements.add(originField);
	//		}
	//		this.associationElements.add(originGetterMethod);
	//		this.associationElements.add(originSetterMethod);
	//	}

	public void addActor(final IConstituent aConstituent)
		throws ModelDeclarationException {
		throw new ModelDeclarationException(
			MultilingualManager.getString(
				"ELEMS_ATTACH",
				ContainerAggregation.class));
	}
	public boolean doesContainActorWithName(final String aName) {
		return this.associationElements.contains(
			this.getActorFromName(aName));
	}
	public void endCloneSession() {
		final ContainerAggregation clonedAggregation =
			(ContainerAggregation) this.getClone();
		if (this.isFromVoid) {
			clonedAggregation.updateAssociation();
		}
		else {
			clonedAggregation.originField =
				(Field) this.originField.getClone();
			clonedAggregation.originGetterMethod =
				(Method) this.originGetterMethod.getClone();
			clonedAggregation.originSetterMethod =
				(Method) this.originSetterMethod.getClone();

			clonedAggregation.associationElements.clear();
			if (!clonedAggregation.isAbstract()) {
				clonedAggregation.associationElements.add(originField);
			}
			clonedAggregation.associationElements.add(
				this.originGetterMethod);
			clonedAggregation.associationElements.add(
				this.originSetterMethod);
		}
	}
	public IConstituent getActorFromName(final String aName) {
		final Iterator iterator = this.associationElements.iterator();

		while (iterator.hasNext()) {
			IConstituent currentElement = (IConstituent) iterator.next();
			if (currentElement.getID().equals(aName)) {
				return currentElement;
			}
		}

		return null;
	}
	public String getFieldType() {
		return this.originField.getType();
	}
	/**
	 * This method returns a list of all the
	 * actors (instances of Association) added to
	 * this container aggregation.
	 */
	// This method is not necessary as of 2005/10/12?
	//	public List listOfActors() {
	//		return this.associationElements;
	//	}
	public void removeActorFromID(final String anID) {
		this.associationElements.remove(this.getActorFromID(anID));
	}
	public void removeAllActors() {
		this.associationElements.clear();
	}
	public void setCardinality(int cardinality)
		throws ModelDeclarationException {

		super.setCardinality(cardinality);
		if (this.isFromVoid) {
			this.updateAssociation();
		}
	}
	public void setName(final String aName) {
		super.setName(aName);
		if (this.isFromVoid) {
			this.updateAssociation();
		}
	}
	public void setTargetActor(Entity aPEntity) {
		super.setTargetActor(aPEntity);

		// Yann 2001/07/31: Robustness?
		// This could happen when cloning a
		// partial subset of the model.
		if (aPEntity != null) {
			if (this.isFromVoid) {
				this.updateAssociation();
			}
		}
	}
	public void setVisibility(int visibility)
		throws ModelDeclarationException {

		super.setVisibility(visibility);
		this.updateAssociation();
	}
	public void startCloneSession() {
		super.startCloneSession();
		final ContainerAggregation clone =
			(ContainerAggregation) this.getClone();

		// New association elements.
		clone.associationElements = new ArrayList(3);

		// New Field("~originField").
		originField.startCloneSession();
		clone.originField = (Field) originField.getClone();

		// New Method("~originGetterMethod").
		this.originGetterMethod.startCloneSession();
		clone.originGetterMethod =
			(Method) this.originGetterMethod.getClone();

		// New Method("~originSetterMethod").
		this.originSetterMethod.startCloneSession();
		clone.originSetterMethod =
			(Method) this.originSetterMethod.getClone();

		// Yann: I am not sure the following lines are needed?
		// clone.originGetterMethod.removeParameter(oneParameter);
		// clone.originSetterMethod.removeParameter(oneParameter);
		// clone.oneParameter = new Parameter(null);
		// clone.originSetterMethod.addParameter(clone.oneParameter);

		// Yann 2002/08/05: Target entity
		// I must update the target correctly.
		// clone.setTargetEntity((Entity) this.getTargetEntity().getClone());
		// However, this is done in the performCloneSession() method from the
		// superclass Use.
	}
	public String toString(final int tab) {
		final StringBuffer codeEq = new StringBuffer();
		codeEq.append(super.toString(tab));

		Util.addTabs(tab, codeEq);
		final Iterator iterator = associationElements.iterator();
		while (iterator.hasNext()) {
			codeEq.append(((Constituent) iterator.next()).toString(tab));
			if (iterator.hasNext()) {
				codeEq.append('\n');
			}
		}

		return codeEq.toString();
	}
	private void updateAssociation() {
		try {
			// Yann 2002/07/31: Update.
			// When an aggregation relationship is built from void,
			// we must create "fake" field and accessor methods.
			this.originField = new Field("~ID1");
			this.originField.setName(this.getName());
			this.originField.setVisibility(this.getVisibility());
			this.originField.setPrivate(true);
			this.originField.resetCodeLines();

			this.originGetterMethod = new Method("~ID2");
			this.originGetterMethod.setVisibility(this.getVisibility());
			// Yann 2004/05/24: Abstractness.
			// The getter method (respectively setter method) might
			// be abstract if the aggregation has been inferred from
			// the methods parameters (in an interface, for example).
			if (!Modifier.isAbstract(this.getVisibility())) {
				this.originGetterMethod.resetCodeLines();
			}

			this.originSetterMethod = new Method("~ID3");
			this.originSetterMethod.setVisibility(this.getVisibility());
			if (!Modifier.isAbstract(this.getVisibility())) {
				this.originSetterMethod.resetCodeLines();
			}

			final Parameter parameter =
				new Parameter(
					padl.util.Util.stripAndCapQualifiedName(
						this.getTargetActor().getName()),
					this.getTargetActor().getName());

			if (this.getCardinality() > 1) {
				this.originField.setType("java.util.List");

				this.originGetterMethod.setName(
					"remove" + this.getTargetActor().getName());
				this.originGetterMethod.addActor(parameter);
				this.originGetterMethod.setReturnType("void");

				this.originSetterMethod.setName(
					"add" + this.getTargetActor().getName());
				this.originSetterMethod.addActor(parameter);
				this.originSetterMethod.setReturnType("void");

				if (!this.isAbstract()) {
					this.originField.setCodeLines(
						"new java.util.ArrayList()");

					this.originGetterMethod.setCodeLines(
						this.getName()
							+ ".add("
							+ parameter.getName()
							+ ");");
					this.originGetterMethod.setReturnType("void");

					this.originSetterMethod.setCodeLines(
						this.getName()
							+ ".remove("
							+ parameter.getName()
							+ ");");
				}
			}
			else {
				this.originField.setType(this.getTargetActor().getName());

				this.originGetterMethod.setName(
					"get" + this.getTargetActor().getName());
				this.originGetterMethod.setReturnType(
					this.getTargetActor().getName());

				this.originSetterMethod.setName(
					"set" + this.getTargetActor().getName());
				this.originSetterMethod.setReturnType("void");
				this.originSetterMethod.addActor(parameter);

				if (!this.isAbstract()) {
					this.originGetterMethod.setCodeLines(
						"return " + this.getName() + ";");

					this.originSetterMethod.setCodeLines(
						this.getName()
							+ " = "
							+ this.getTargetActor().getName()
							+ ';');
				}
			}

			if (this.associationElements == null) {
				this.associationElements = new ArrayList(3);
			}
			else {
				this.associationElements.clear();
			}
			if (!this.isAbstract()) {
				this.associationElements.add(originField);
			}
			this.associationElements.add(originGetterMethod);
			this.associationElements.add(originSetterMethod);
		}
		catch (final ModelDeclarationException pde) {
			pde.printStackTrace(Output.getInstance().errorOutput());
		}
	}
}