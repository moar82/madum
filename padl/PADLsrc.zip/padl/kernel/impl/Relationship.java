/*
 * (c) Copyright 2001, 2002 Herv� Albin-Amiot and Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * Soft-Maint S.A.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

import padl.kernel.Constants;
import padl.kernel.IElementMarker;
import padl.kernel.IEntity;
import padl.kernel.IRelationship;
import padl.kernel.exception.ModelDeclarationException;
import padl.util.Util;
import util.io.Output;
import util.lang.Modifier;
import util.multilingual.MultilingualManager;

abstract class Relationship
	extends Element
	implements IElementMarker, IRelationship {

	private int cardinality;
	private IEntity targetEntity;

	public Relationship(final String anActorID) {
		super(anActorID);
	}
	public int getCardinality() {
		return this.cardinality;
	}
	public IEntity getTargetActor() {
		return this.targetEntity;
	}
	public void performCloneSession() {
		super.performCloneSession();
		UseRelationship clone = (UseRelationship) this.getClone();
		clone.setTargetActor((Entity) this.targetEntity.getClone());
	}
	public void setCardinality(int aCardinality)
		throws ModelDeclarationException {

		if (aCardinality < 1) {
			throw new ModelDeclarationException(
				MultilingualManager.getString(
					"CARDINALITY",
					Relationship.class,
					new Object[] { new Integer(cardinality)}));
		}

		this.cardinality = aCardinality;
	}
	public void setTargetActor(final IEntity anEntity) {
		this.targetEntity = anEntity;
	}
	public String toString() {
		if (Constants.DEBUG) {
			Output.getInstance().debugOutput().print("// ");
			Output.getInstance().debugOutput().print(this.getClass());
			Output.getInstance().debugOutput().println(".toString()");
		}
		return this.toString(0);
	}
	public String toString(final int tab) {
		final StringBuffer buffer = new StringBuffer();
		Util.addTabs(tab, buffer);
		buffer.append(this.getClass().getName());
		buffer.append("\nName: ");
		buffer.append(this.getName());
		buffer.append("\nWith: ");
		buffer.append(this.getTargetActor().getName());
		buffer.append("\nVisibility: ");
		buffer.append(Modifier.toString(this.getVisibility()));
		buffer.append(", cadinality: ");
		buffer.append(this.getCardinality());
		buffer.append('\n');
		return buffer.toString();
	}
}