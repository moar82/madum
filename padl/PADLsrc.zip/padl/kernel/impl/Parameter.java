/*
 * (c) Copyright 2001, 2002 Herv� Albin-Amiot and Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * Soft-Maint S.A.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

import padl.kernel.IEntity;
import padl.kernel.IParameter;
import padl.util.Util;

class Parameter extends Element implements IParameter {
	private int cardinality = 1;
	private String name;
	private String type;

	public Parameter(final String aType) {
		super("Parameter");

		this.setNameFromType(aType);
		this.setType(aType);
	}
	public Parameter(final String aName, final IEntity anEntity) {
		super("Parameter");

		this.setName(aName);
		this.setType(anEntity.getName());
	}
	public Parameter(final String aName, final String aType) {
		super("Parameter");

		this.setName(aName);
		this.setType(aType);
	}
	// Yann 2006/03/28: Need?
	// Do I need to have this method now that
	// I inherit from Consituent?
	//	public void accept(final IVisitor visitor) {
	//		visitor.visit(this);
	//	}
	private String clean(
		final String aString,
		final boolean computeCardinality) {

		final String cleanString;
		int index = aString.indexOf('[');
		if (index > -1) {
			cleanString = aString.substring(0, index);

			// Yann 2004/08/10: Cardinality.
			// I compute the cardinality by counting the
			// number of opening brackets.
			if (computeCardinality) {
				this.cardinality++;
				while ((index = aString.indexOf('[', index + 1)) > -1) {
					this.cardinality++;
				}
			}
		}
		else {
			cleanString = aString;
		}

		return cleanString;
	}
	public int getCardinality() {
		return this.cardinality;
	}
	public String getName() {
		return this.name;
	}
	public String getType() {
		return this.type;
	}
	public void setCardinality(final int aCardinality) {
		this.cardinality = aCardinality;
	}
	public void setName(final String aName) {
		this.name = this.clean(aName, true);
	}
	public void setNameFromType(final String aType) {
		final String cleanType = this.clean(aType, false);

		final StringBuffer buffer = new StringBuffer(cleanType.length() + 1);
		buffer.append('a');
		buffer.append(
			Util.capitalizeFirstLetter(
				Util.stripAndCapQualifiedName(cleanType)));

		this.name = buffer.toString();
	}
	public void setType(final String aType) {
		this.type = this.clean(aType, true);
	}
	public String toString() {
		return this.getType() + ' ' + this.getName();
	}
}
