/*
 * (c) Copyright 2001, 2002 Herv� Albin-Amiot and Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * Soft-Maint S.A.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

import padl.kernel.IConstituent;
import padl.kernel.IDesignLevelModel;
import padl.kernel.IEntity;
import padl.kernel.IIdiomLevelModel;
import padl.kernel.IPackage;
import padl.kernel.exception.ModelDeclarationException;
import util.multilingual.MultilingualManager;

class IdiomLevelModel
	extends AbstractLevelModel
	implements IIdiomLevelModel, Cloneable {

	private String modelName;

	public IdiomLevelModel() {
		this("IdiomLevelModel");
	}
	public IdiomLevelModel(final String modelName) {
		this.modelName = modelName;
	}
	public void addActor(final IConstituent aConstituent)
		throws ModelDeclarationException {

		if (aConstituent instanceof IEntity) {
			this.addActor((IEntity) aConstituent);
		}
		else if (aConstituent instanceof IPackage) {
			this.addActor((IPackage) aConstituent);
		}
		else {
			throw new ModelDeclarationException(
				MultilingualManager.getString(
					"ENT_ADD_ORG_LEVEL",
					IdiomLevelModel.class));
		}
	}
	public void addActor(final IEntity anEntity)
		throws ModelDeclarationException {

		super.addActor(anEntity);
	}
	public void addActor(final IPackage aPackage)
		throws ModelDeclarationException {

		super.addActor(aPackage);
	}
	//	public void create(final IIdiomLevelModelCreator anIdiomLevelCreator) {
	//		anIdiomLevelCreator.create(this);
	//
	//		// Yann 2004/04/10: History!
	//		// The following code is now located (and improved) in the
	//		// ClassFileCompeteCreator.create() method!
	//		//	final List listOfSourceConstituents =
	//		//		anIdiomLevelCreator.getListOfSourceConstituents();
	//		//
	//		//	final ConstituentRepository constituentRepository =
	//		//		ConstituentRepository.getCurrentTypeRepository();
	//		//
	//		//	final ClassFile[] listOfEntities =
	//		//		constituentRepository.getEntities();
	//		//	final ClassFile[] listOfElements =
	//		//		constituentRepository.getElements();
	//		//
	//		//	int[] sortedEntities = new int[listOfEntities.length];
	//		//	int[] sortedElements = new int[listOfElements.length];
	//		//
	//		//	final StringBuffer buffer = new StringBuffer();
	//		//	String constituentName;
	//		//
	//		//	// Herv� a couple of years ago...
	//		//	// Analyses of the Entities,
	//		//	// sort based on the recognizeRequestOrder() method.
	//		//	// Yann 2003/12/22: IIdiomLevelCreator.
	//		//	// I now use the methods defined in the creator that
	//		//	// I introduce to allow different creators.
	//		//	//	for (int x = 0; x < listOfEntities.length; x++) {
	//		//	//		try {
	//		//	//			sortedEntities[x] =
	//		//	//				((Integer) Misc
	//		//	//					.getDeclaredMethod(
	//		//	//						constituentRepository.getEntities()[x],
	//		//	//						"recognizeRequestOrder")
	//		//	//					.invoke(null, new Object[0]))
	//		//	//					.intValue();
	//		//	//		}
	//		//	//		catch (final Exception e) {
	//		//	//			e.printStackTrace(ListenerManager.getCurrentListenerManager().getOutput());
	//		//	//		}
	//		//	//	}
	//		//	//	sortedEntities = this.sortByPriority(sortedEntities);
	//		//	for (int x = 0; x < listOfEntities.length; x++) {
	//		//		constituentName =
	//		//			constituentRepository.getEntities()[x].getName();
	//		//
	//		//		try {
	//		//			buffer.append("recognize");
	//		//			buffer.append(
	//		//				constituentName.substring(
	//		//					constituentName.lastIndexOf('.') + 1));
	//		//			buffer.append("Priority");
	//		//			sortedEntities[x] =
	//		//				((Integer) anIdiomLevelCreator
	//		//					.getClass()
	//		//					.getMethod(buffer.toString(), new java.lang.Class[0])
	//		//					.invoke(anIdiomLevelCreator, new Object[0]))
	//		//					.intValue();
	//		//			buffer.setLength(0);
	//		//		}
	//		//		catch (final Exception e) {
	//		//			e.printStackTrace(ListenerManager.getCurrentListenerManager().getOutput());
	//		//		}
	//		//	}
	//		//	sortedEntities = this.sortByPriority(sortedEntities);
	//		//
	//		//	// I compare the user's given entities against the Entities.
	//		//	for (int x = 0;
	//		//		x < listOfEntities.length && listOfSourceConstituents.size() > 0;
	//		//		x++) {
	//		//
	//		//		try {
	//		//			// Yann 2001/08/10: Hard to use ClassLoader!
	//		//			// I found a new bug linked to the use of a special instance of
	//		//			// ClassLoader. In the Eclipse version of Ptidej, all the
	//		//			// classes are loader through the Eclipse-specific class loader.
	//		//			// Thus, any use (on a non-system class) of the special field
	//		//			// .class calls the Eclipse class loader. Indeed, a the statement
	//		//			// IdiomLevelModel.class returned in fact:
	//		//			//     <Eclipse class loader>.IdiomLevelModel
	//		//			// And the method getMethod() threw an instance of exception
	//		//			// NoSuchMethodException, since it was expecting:
	//		//			//     <PatternsBox class loader>.IdiomLevelModel
	//		//			// The correction is: For the system class, the use of special
	//		//			// field .class is okay (the system class loader is the
	//		//			// superclass of all class loaders). For application-specific
	//		//			// classes, *never* use the special field .class, always use:
	//		//			//     <instance of a class loader>.loadClass(<class name>)
	//		//			//
	//		//			// Yann 2002/07/28: A year later...
	//		//			// I replaced use of the reflection API with instances of
	//		//			// the class ClassFile from CFParse. I also cleanup a bit
	//		//			// this method, in particular, I removed the local variable
	//		//			// paramIn.
	//		//			//
	//		//			// Yann 2003/02/22: Cleaning!
	//		//			// I want to include the implementation in my Ph.D. thesis,
	//		//			// so I tidy up a litte the code...
	//		//			ListenerManager
	//		//				.getCurrentListenerManager()
	//		//				.firePatternChange(
	//		//				IListener.ENTITY_RECOGNIZED,
	//		//				new RecognitionEvent(
	//		//					constituentRepository
	//		//						.getEntities()[sortedEntities[x]]
	//		//						.getName()));
	//		//
	//		//			// The method recognize takes a list of submitted PEntities,
	//		//			// and return a list with the PEntities not recognized
	//		//			// (that it remains to recognize).
	//		//
	//		//			// Yann 2002/07/29: No more clone...
	//		//			// I do not reassign the result of the recognize(...) method
	//		//			// to the current list of submitted classes. Indeed, PClass
	//		//			// and PInterfaces both already take care of sorting out
	//		//			// the instances of ClassFile according to their needs.
	//		//			// The assignation only saved some iterations when linking
	//		//			// interfaces together...
	//		//			// Yann 2003/12/22: IIdiomLevelModelCreator.
	//		//			// I now use the method provided by the instance
	//		//			// of IIdiomLevelModelCreator.
	//		//			//	Misc
	//		//			//		.getDeclaredMethod(
	//		//			//			constituentRepository
	//		//			//				.getEntities()[sortedEntities[x]],
	//		//			//			"recognize")
	//		//			//		.invoke(
	//		//			//			null,
	//		//			//			new Object[] { listOfSourceConstituents, this });
	//		//			constituentName =
	//		//				constituentRepository
	//		//					.getEntities()[sortedEntities[x]]
	//		//					.getName();
	//		//			buffer.append("recognize");
	//		//			buffer.append(
	//		//				constituentName.substring(
	//		//					constituentName.lastIndexOf('.') + 1));
	//		//			anIdiomLevelCreator
	//		//				.getClass()
	//		//				.getMethod(
	//		//					buffer.toString(),
	//		//					new java.lang.Class[] {
	//		//						List.class,
	//		//						IIdiomLevelModel.class })
	//		//				.invoke(
	//		//					anIdiomLevelCreator,
	//		//					new Object[] { listOfSourceConstituents, this });
	//		//			buffer.setLength(0);
	//		//		}
	//		//		catch (final Exception e) {
	//		//			e.printStackTrace(ListenerManager.getCurrentListenerManager().getOutput());
	//		//		}
	//		//	}
	//		//
	//		//	// Analyses of the Elements,
	//		//	// sort based on the recognizeRequestOrder() method.
	//		//	//	for (int x = 0; x < listOfElements.length; x++) {
	//		//	//		try {
	//		//	//			sortedElements[x] =
	//		//	//				((Integer) Misc
	//		//	//					.getDeclaredMethod(
	//		//	//						constituentRepository.getElements()[x],
	//		//	//						"recognizeRequestOrder")
	//		//	//					.invoke(null, new Object[0]))
	//		//	//					.intValue();
	//		//	//		}
	//		//	//		catch (final Exception e) {
	//		//	//			e.printStackTrace(ListenerManager.getCurrentListenerManager().getOutput());
	//		//	//		}
	//		//	//	}
	//		//	//	sortedElements = this.sortByPriority(sortedElements);
	//		//	for (int x = 0; x < listOfElements.length; x++) {
	//		//		constituentName =
	//		//			constituentRepository.getElements()[x].getName();
	//		//
	//		//		try {
	//		//			buffer.append("recognize");
	//		//			buffer.append(
	//		//				constituentName.substring(
	//		//					constituentName.lastIndexOf('.') + 1));
	//		//			buffer.append("Priority");
	//		//			sortedElements[x] =
	//		//				((Integer) anIdiomLevelCreator
	//		//					.getClass()
	//		//					.getMethod(buffer.toString(), new java.lang.Class[0])
	//		//					.invoke(anIdiomLevelCreator, new Object[0]))
	//		//					.intValue();
	//		//			buffer.setLength(0);
	//		//		}
	//		//		catch (final Exception e) {
	//		//			e.printStackTrace(ListenerManager.getCurrentListenerManager().getOutput());
	//		//		}
	//		//	}
	//		//	sortedElements = this.sortByPriority(sortedElements);
	//		//
	//		//	// Yann 2002/08/01: Concurrent modification.
	//		//	// While I iterate over the list of entities,
	//		//	// I may want to add new entities (instances of Ghost),
	//		//	// thus I cannot use the iterator mechanism provided
	//		//	// by Java, because it implements a fail-safe security.
	//		//	final List temporayListOfEntities = this.listOfActors();
	//		//	for (int i = 0; i < temporayListOfEntities.size(); i++) {
	//		//
	//		//		// I look for the entity corresponding instance of class Class.
	//		//		// I cannot use:
	//		//		//      Class.forName(((Entity) enum.nextElement()).getName())
	//		//		// Since the given user's classes may not be in the classpath and
	//		//		// have been loaded from a different class loader.
	//		//		final IEntity entity = (IEntity) temporayListOfEntities.get(i);
	//		//		final String currentClassName = entity.getName();
	//		//
	//		//		if (!(entity instanceof IGhost)) {
	//		//			ListenerManager
	//		//				.getCurrentListenerManager()
	//		//				.firePatternChange(
	//		//				IListener.ENTITY_ANALYZED,
	//		//				new AnalysisEvent(currentClassName));
	//		//
	//		//			final Iterator enumClasses =
	//		//				listOfSourceConstituents.iterator();
	//		//			ClassFile currentClass = null;
	//		//
	//		//			// I can use such a loop since I know (for sure) that the Class
	//		//			// I'm looking for exists.
	//		//			while (enumClasses.hasNext()
	//		//				&& !(currentClass = (ClassFile) enumClasses.next())
	//		//					.getName()
	//		//					.equals(
	//		//					currentClassName));
	//		//
	//		//			// I reset the list of submitted elements and entities.
	//		//			List listOfSubmittedElements = new ArrayList();
	//		//
	//		//			// I fill up the Element.
	//		//			for (int x = 0;
	//		//				x < currentClass.getMethods().length();
	//		//				listOfSubmittedElements.add(
	//		//					new ExtendedMethodInfo(
	//		//						currentClass,
	//		//						currentClass.getMethods().get(x++))));
	//		//			for (int x = 0;
	//		//				x < currentClass.getFields().length();
	//		//				listOfSubmittedElements.add(
	//		//					new ExtendedFieldInfo(
	//		//						currentClass,
	//		//						currentClass.getFields().get(x++))));
	//		//
	//		//			for (int x = 0;
	//		//				x < listOfElements.length
	//		//					&& listOfSubmittedElements.size() > 0;
	//		//				x++) {
	//		//
	//		//				try {
	//		//					// Yann 2002/07/31: Priorities.
	//		//					// I must keep the fields and the methods in
	//		//					// the list of submitted constituents,
	//		//					// because they might be used later to create
	//		//					// a Aggregation linked with them.
	//		//					// Yann 2003/12/22: IIdiomLevelModelCreator.
	//		//					// I now use the method provided by the instance
	//		//					// of IIdiomLevelModelCreator.
	//		//					//	Misc
	//		//					//		.getDeclaredMethod(
	//		//					//			constituentRepository
	//		//					//				.getElements()[sortedElements[x]],
	//		//					//			"recognize")
	//		//					//		.invoke(
	//		//					//			null,
	//		//					//			new Object[] {
	//		//					//				listOfSubmittedElements,
	//		//					//				this });
	//		//					constituentName =
	//		//						constituentRepository
	//		//							.getElements()[sortedElements[x]]
	//		//							.getName();
	//		//					buffer.append("recognize");
	//		//					buffer.append(
	//		//						constituentName.substring(
	//		//							constituentName.lastIndexOf('.') + 1));
	//		//					anIdiomLevelCreator
	//		//						.getClass()
	//		//						.getMethod(
	//		//							buffer.toString(),
	//		//							new java.lang.Class[] {
	//		//								List.class,
	//		//								IIdiomLevelModel.class })
	//		//						.invoke(
	//		//							anIdiomLevelCreator,
	//		//							new Object[] {
	//		//								listOfSubmittedElements,
	//		//								this });
	//		//				}
	//		//				catch (final InvocationTargetException e) {
	//		//					ListenerManager.getCurrentListenerManager().getOutput().print("Error: ");
	//		//					ListenerManager.getCurrentListenerManager().getOutput().println(
	//		//						listOfElements[sortedElements[x]].getName());
	//		//					e.printStackTrace(ListenerManager.getCurrentListenerManager().getOutput());
	//		//				}
	//		//				catch (final IllegalAccessException iae) {
	//		//					iae.printStackTrace(ListenerManager.getCurrentListenerManager().getOutput());
	//		//				}
	//		//				catch (final NoSuchMethodException nsme) {
	//		//					nsme.printStackTrace(ListenerManager.getCurrentListenerManager().getOutput());
	//		//				}
	//		//				finally {
	//		//					buffer.setLength(0);
	//		//				}
	//		//			}
	//		//		}
	//		//		else {
	//		//			ListenerManager
	//		//				.getCurrentListenerManager()
	//		//				.firePatternChange(
	//		//				IListener.ENTITY_SKIPPED,
	//		//				new AnalysisEvent(currentClassName));
	//		//		}
	//		//
	//		//	}
	//	}
	//	public List compare(final IAbstractModel aPattern) {
	//		// Shadowing AbstractLevelModel's compare, because this method does not make sense here.
	//		return null;
	//	}
	//	public Map compare(final PatternRepository aPatternsRepository) {
	//		final Map results = new HashMap();
	//		for (int x = 0;
	//			x < aPatternsRepository.listOfPatterns().length;
	//			x++) {
	//			(
	//				(IPatternModel) aPatternsRepository
	//					.listOfPatterns()[x])
	//					.setDetector(
	//				new Detector());
	//			results.put(
	//				aPatternsRepository.listOfPatterns()[x].getName(),
	//				aPatternsRepository.listOfPatterns()[x].compare(this));
	//		}
	//		return results;
	//	}
	public String getName() {
		return this.modelName;
	}
	//	public static void main(final String args[]) {
	//		// I parse the arguments (if any)
	//		String path =
	//			"C:/Documents and Settings/Yann/Work/Workspace/Ptidej Tests/ptidej/tests/composite2/";
	//		if (args != null) {
	//			if (args.length == 1) {
	//				path = args[0];
	//			}
	//			else {
	//				if (args.length != 0) {
	//					ListenerManager.getCurrentListenerManager().getOutput().println(
	//						"Usage: java padl.kernel.abstractlevel.IdiomLevelModel <classpath> <packge name>");
	//				}
	//			}
	//		}
	//
	//		final IIdiomLevelModel idiomLevelModel =
	//			Factory.getUniqueInstance().createIdiomLevelModel(path);
	//		final ModelStatistics patternStatistics = new ModelStatistics();
	//		ListenerManager.getCurrentListenerManager().addPatternListener(
	//			patternStatistics);
	//
	//		try {
	//			// Building the program representation.
	//			idiomLevelModel.create(
	//				new ClassFileCompleteCreator(
	//					Loader.loadSubtypesFromDir(null, path, ".class")));
	//			ListenerManager.getCurrentListenerManager().getOutput().println();
	//			ListenerManager.getCurrentListenerManager().getOutput().println(patternStatistics);
	//
	//			// Detecting design pattern.
	//			ListenerManager.getCurrentListenerManager().getOutput().println();
	//			final Map solutions =
	//				idiomLevelModel.compare(
	//					PatternRepository.getCurrentPatternRepository());
	//
	//			// Display solutions...
	//			final Iterator iterator = solutions.keySet().iterator();
	//			while (iterator.hasNext()) {
	//				final String currentPattern = (String) iterator.next();
	//				final List patternSolutions =
	//					(List) solutions.get(currentPattern);
	//				ListenerManager.getCurrentListenerManager().getOutput().println(
	//					"* Model: "
	//						+ currentPattern
	//						+ ": "
	//						+ patternSolutions.size()
	//						+ " instance(s).");
	//				if (patternSolutions.size() > 0) {
	//					final Iterator iterator2 = patternSolutions.iterator();
	//					while (iterator2.hasNext()) {
	//						final Map currentSol = (Map) iterator2.next();
	//						final Iterator iterator3 =
	//							currentSol.keySet().iterator();
	//						while (iterator3.hasNext()) {
	//							final String currentActor =
	//								(String) iterator3.next();
	//							ListenerManager.getCurrentListenerManager().getOutput().print(currentActor);
	//							ListenerManager.getCurrentListenerManager().getOutput().println(':');
	//							final Iterator iterator4 =
	//								((List) currentSol.get(currentActor))
	//									.iterator();
	//							while (iterator4.hasNext()) {
	//								ListenerManager.getCurrentListenerManager().getOutput().print('\t');
	//								ListenerManager.getCurrentListenerManager().getOutput().println(
	//									((IEntity) iterator4.next()).getName());
	//							}
	//							ListenerManager.getCurrentListenerManager().getOutput().println();
	//						}
	//						ListenerManager.getCurrentListenerManager().getOutput().println("----");
	//					}
	//				}
	//			}
	//		}
	//		catch (final Exception e) {
	//			e.printStackTrace(ListenerManager.getCurrentListenerManager().getOutput());
	//		}
	//	}
	public IDesignLevelModel upgrade(final String aName) {
		final IDesignLevelModel designLevelModel =
			Factory.getInstance().createDesignLevelModel(aName);

		this.clone(designLevelModel);

		return designLevelModel;
	}
}