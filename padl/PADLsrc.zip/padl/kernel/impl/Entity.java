/*
 * (c) Copyright 2001, 2002 Herv� Albin-Amiot and Yann-Ga�l Gu�h�neuc, Ecole
 * des Mines de Nantes Object Technology International, Inc. Soft-Maint S.A.
 * 
 * Use and copying of this software and preparation of derivative works based
 * upon this software are permitted. Any copy of this software or of any
 * derivative work must include the above copyright notice of the authors, this
 * paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, AND NOT
 * WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY LIABILITY FOR DAMAGES
 * RESULTING FROM THE SOFTWARE OR ITS USE IS EXPRESSLY DISCLAIMED, WHETHER
 * ARISING IN CONTRACT, TORT (INCLUDING NEGLIGENCE) OR STRICT LIABILITY, EVEN
 * IF THE AUTHORS ARE ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import padl.kernel.IConstituent;
import padl.kernel.IElement;
import padl.kernel.IEntity;
import padl.kernel.IMemberClass;
import padl.kernel.IMemberGhost;
import padl.kernel.IMemberInterface;
import padl.kernel.IRelationship;
import padl.kernel.IVisitor;
import padl.kernel.exception.ModelDeclarationException;
import padl.util.Util;
import util.io.Output;
import util.multilingual.MultilingualManager;

abstract class Entity extends Constituent implements IEntity {
	// Yann: 2002/07/29: Final!
	// The following fields cannot be final! Because I need to set them
	// up to different values in the performCloneSession() method.
	// (See below...)

	private List listOfInheritedEntities = new ArrayList();
	private List listOfInheritingEntities = new ArrayList();
	private String purpose;

	public Entity(final String actorID) {
		super(actorID);
	}
	public boolean equalsMember(final IEntity memberEntity) {
		// Yann 2006/02/21: Member entities...
		// Two member entities may have indentical names,
		// as well as identical other attributes but for
		// their JVM-based object id.
		// Stephane 2006/03/23: Naming of Member entities
		// is incorrect by spec: 
		// http://java.sun.com/docs/books/jls/second_edition/html/classes.doc.html#246026
		// this is a hack before member entity ids are changed
		// a lesser hack could include creating a MemberEntity type 
		return System.identityHashCode(this)
			== System.identityHashCode(memberEntity);
	}
	public boolean equals(final Object anObject) {
		if (anObject instanceof IMemberClass
			|| anObject instanceof IMemberInterface
			|| anObject instanceof IMemberGhost) {
			return this.equalsMember((IEntity) anObject);
		}
		return super.equals(anObject);
	}

	public void accept(final IVisitor visitor) {
		this.accept(visitor, "open");
		final Iterator iterator = this.getIteratorOnConcurrentActors();
		while (iterator.hasNext()) {
			final IConstituent constituent = (IConstituent) iterator.next();
			// System.out.println(constituent.toString());
			constituent.accept(visitor);
		}
		this.accept(visitor, "close");
	}
	public void addActor(final IConstituent aConstituent)
		throws ModelDeclarationException {

		if (aConstituent instanceof IElement) {
			this.addActor((IElement) aConstituent);
		}
		else {
			throw new ModelDeclarationException(
				MultilingualManager.getString("ELEM_ADD_ENT", Entity.class));
		}
	}
	public void addActor(final IElement anElement)
		throws ModelDeclarationException {

		// Yann 2004/05/21: Abstractness.
		// Any method added to an abstract class must be abstract too.
		// This is NOT true! An abstract class may contain concrete
		// methods... Even constructor!?
		// anElement.setAbstract(this.isAbstract());
		if (anElement instanceof IRelationship) {
			this.addActor((IRelationship) anElement);
		}
		else {
			super.addActor(anElement);
		}
	}
	public void addActor(final IRelationship aRelationship)
		throws ModelDeclarationException {

		this.sortAndAddActorWithUniqueID(aRelationship);
	}
	public void addInheritedActor(final IEntity anEntity)
		throws ModelDeclarationException {
		// Yann 2002/08/01: Ghost!
		// I added a new kind of entity, Ghost, to represent unavailable
		// classes and interfaces. Thus, the following test is not valid
		// anymore. Moreover, I wonder if this test is in the right place...
		//	if (aPEntity.getClass() != this.getClass()) {
		//		throw new ModelDeclarationException(
		//			this.getClass()
		//				+ " can only inherit from a "
		//				+ this.getClass());
		//	}
		if (anEntity == this) {
			throw new ModelDeclarationException(
				MultilingualManager.getString(
					"ENT_INHERIT_ITSELF",
					Entity.class));
		}
		if (this.listOfInheritedEntities.contains(anEntity)) {
			throw new ModelDeclarationException(
				MultilingualManager.getString(
					"ALREADY_INHERITED",
					Entity.class,
					new Object[] { anEntity.getID(), this.getID()}));
		}
		this.listOfInheritedEntities.add(anEntity);
		//	this.addActor(
		//		new Specialisation("S" + anEntity.getActorID(), anEntity));

		 ((Entity) anEntity).addInheritingActor(this);
		//	anEntity.addActor(
		//		new Generalisation("G" + this.getActorID(), this));
	}
	/**
	 * This method add a new entity to the list of entities
	 * inheriting from this entity.
	 * 
	 * @param anEntity
	 * @throws ModelDeclarationException
	 */
	protected void addInheritingActor(final IEntity anEntity)
		throws ModelDeclarationException {
		if (anEntity == this) {
			throw new ModelDeclarationException(
				MultilingualManager.getString(
					"ENT_INHERIT_ITSELF",
					Entity.class));
		}
		if (this.listOfInheritedEntities.contains(anEntity)) {
			throw new ModelDeclarationException(
				MultilingualManager.getString(
					"ALREADY_INHERITED",
					Entity.class,
					new Object[] { anEntity.getID(), this.getID()}));
		}
		this.listOfInheritingEntities.add(anEntity);
	}
	public void endCloneSession() {
		// I finish the clone session of the elements.
		final Iterator iterator = this.getIteratorOnActors();
		while (iterator.hasNext()) {
			((IConstituent) iterator.next()).endCloneSession();
		}
		super.endCloneSession();
	}
	public IEntity getInheritedActor(final String anEntityName) {
		final Iterator iterator = this.listOfInheritedEntities.iterator();
		while (iterator.hasNext()) {
			final Entity inheritedEntity = (Entity) iterator.next();
			if (inheritedEntity.getName().equals(anEntityName)) {
				return inheritedEntity;
			}
		}
		return null;
	}
	public String getPurpose() {
		return this.purpose;
	}
	public boolean isAboveInHierarchy(final IEntity pEntity) {
		if (this.equals(pEntity)) {
			return true;
		}
		else {
			final Iterator iterator =
				pEntity.listOfInheritedActors().iterator();
			while (iterator.hasNext()) {
				IEntity s = (IEntity) iterator.next();
				if (this.equals(s)) {
					return true;
				}
				else {
					return this.isAboveInHierarchy(s);
				}
			}
		}
		return false;
	}
	/**
	 * This method returns the list of all entities inheriting from this
	 * entity.
	 * 
	 * @return list of inheriting actors
	 */
	public List listOfInheritingActors() {
		return this.listOfInheritingEntities;
	}
	public List listOfInheritedActors() {
		return this.listOfInheritedEntities;
	}
	public void performCloneSession() {
		super.performCloneSession();

		final Entity clonedEntity = (Entity) this.getClone();
		Iterator iterator;

		// Duplicate the hierarchies.
		clonedEntity.listOfInheritedEntities = new ArrayList();
		iterator = this.listOfInheritedEntities.iterator();
		while (iterator.hasNext()) {
			final Entity currentPEntity = (Entity) iterator.next();
			// Yann: The following lines are not needed anymore?
			// if (currentPEntity.isCloned()) {
			// clonedEntity.removeInherits(currentPEntity);
			// Yann 2001/07/31: Hack!
			// The following test is only needed when cloning
			// a subset of the model.
			// A better and *cleaner* algorithm must be
			// implemented eventually.
			if (currentPEntity.getClone() != null) {
				clonedEntity.listOfInheritedEntities.add(
					currentPEntity.getClone());
			}
		}

		// Yann: Start clone session of the entity's elements.
		// The new clone protocol makes explicit the needed shift
		// between the beginning of the cloning of the Entities
		// and the beginning of the cloning of the Elements.
		iterator = this.getIteratorOnActors();
		while (iterator.hasNext()) {
			final IElement element = (IElement) iterator.next();
			if (!(element instanceof IEntity)) {
				element.startCloneSession();
			}
		}

		// I perform the clone session of the elements.
		iterator = this.getIteratorOnActors();
		while (iterator.hasNext()) {
			final IElement element = (IElement) iterator.next();
			element.performCloneSession();
			// Yann 2004/12/17: Clone!
			// I must use the addActor() method to add the cloned
			// element to the cloned entity or I might have problems
			// (in particular with the cache implemented in class
			// AbstractContainer).
			// Yann 2006/08/09: Clone and member entities...
			// Once upon a time, there was a gug that prevented elements
			// of member entities to be create. I fixed that bug but it
			// undercovered another bug in the cloning process: I was
			// checking if an element was also en entity (case of a 
			// member entity) and put the test *before* calling
			// "performCloneSession()" on this member entity, thus 
			// preventing the elements of the member entity to be cloned!
			// I moved the test just after "performCloneSession()" just
			// to make sure I am not adding a member entity already added
			// (during "startCloneSession()"). Thanks to Saliha for
			// revealing this bug!
			if (!(element instanceof IEntity)) {
				try {
					clonedEntity.addActor((IElement) element.getClone());
				}
				catch (final ModelDeclarationException e) {
					e.printStackTrace(Output.getInstance().errorOutput());
				}
			}
		}
	}
	public void removeInheritedActor(final IEntity anEntity) {
		this.listOfInheritedEntities.remove(anEntity);
	}
	public void setPurpose(final String purpose) {
		this.purpose = purpose;
	}
	public void startCloneSession() {
		// The shallow copy must include a shallow copy of 
		// member entities, because the clones of methods,
		// fields, and so on, depend on it!
		super.startCloneSession();

		((Entity) this.getClone()).resetListOfActors();

		final Iterator iterator = this.getIteratorOnActors(IEntity.class);
		while (iterator.hasNext()) {
			final IEntity entity = (IEntity) iterator.next();
			entity.startCloneSession();
			try {
				((Entity) this.getClone()).addActor(entity.getClone());
			}
			catch (final ModelDeclarationException pde) {
				pde.printStackTrace(Output.getInstance().errorOutput());
			}
		}
	}
	public String toString() {
		return this.toString(0);
	}
	public String toString(final int tab) {
		final StringBuffer codeEq = new StringBuffer();
		if (getPurpose() != null) {
			Util.addTabs(tab, codeEq);
			codeEq.append("/* ");
			codeEq.append(getID());
			codeEq.append(" : Purpose\n");
			Util.addTabs(tab, codeEq);
			codeEq.append(getPurpose());
			Util.addTabs(tab, codeEq);
			codeEq.append("\n*/\n");
		}
		codeEq.append(super.toString(tab));
		return codeEq.toString();
	}
}