/*
 * (c) Copyright 2001, 2002 Herv� Albin-Amiot and Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * Soft-Maint S.A.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import padl.kernel.IClass;
import padl.kernel.IElement;
import padl.kernel.IEntityMarker;
import padl.kernel.IInterface;
import padl.kernel.exception.ModelDeclarationException;

class Interface extends Entity implements IEntityMarker, IInterface {
	private final List shouldImplementEventList = new ArrayList();

	public Interface(final String anActorID) {
		super(anActorID);
	}
	public void addActor(final IElement anElement)
		throws ModelDeclarationException {
		anElement.setAbstract(true);
		super.addActor(anElement);
	}
	public void endCloneSession() {
		super.endCloneSession();
		this.shouldImplementEventList.clear();
	}
	public void startCloneSession() {
		super.startCloneSession();

		// Duplicate hierarchy.
		final Interface clonedPInterface = (Interface) this.getClone();
		final Iterator iterator = this.shouldImplementEventList.iterator();
		while (iterator.hasNext()) {
			final IClass currentTarget = (IClass) iterator.next();
			currentTarget.removeImplementedActor(this);
			try {
				currentTarget.addImplementedActor(clonedPInterface);
			}
			catch (final ModelDeclarationException e) {
			}
		}
	}
	public String toString() {
		final StringBuffer codeEq = new StringBuffer();
		codeEq.append(super.toString());
		codeEq.append(" interface ");
		codeEq.append(getName());
		if (this.listOfInheritedActors().size() > 0) {
			codeEq.append(" extends ");
			final Iterator iterator = this.listOfInheritedActors().iterator();
			while (iterator.hasNext()) {
				codeEq.append(((Entity) (iterator.next())).getName());
				if (iterator.hasNext())
					codeEq.append(", ");
			}
		}
		return codeEq.toString();
	}
}
