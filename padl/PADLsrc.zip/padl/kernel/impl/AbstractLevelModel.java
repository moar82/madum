/*
 * (c) Copyright 2001, 2002 Herv� Albin-Amiot and Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * Soft-Maint S.A.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

import java.util.Iterator;

import padl.kernel.IAbstractLevelModel;
import padl.kernel.IConstituent;
import padl.kernel.IFactory;
import padl.kernel.IGenerator;
import padl.kernel.ISubject;
import padl.kernel.IWalker;
import padl.kernel.exception.ModelDeclarationException;
import util.io.Output;

abstract class AbstractLevelModel
	extends AbstractContainer
	implements IAbstractLevelModel, ISubject {

	private IFactory factory;

	public void addGhostActor(final String aName)
		throws ModelDeclarationException {

		super.addActor(this.getFactory().createGhost(aName));
	}
	public final Object clone() throws CloneNotSupportedException {
		// Yann: Here is the new clone protocole. This is subject
		// to discussion!! The idea is that a model may be cloned,
		// but a constituent of a model (Element or Entity) may
		// not be cloned individually, it does not make sense to clone
		// a Method if the rest of the model is not cloned to. I
		// believe this is actually a risk: to be able to clone a single
		// constituent on an individual basis may prove to create
		// duplicates with references on current objects...
		// Thus, only the AbstractLevelModel class implements the Cloneable interface.
		// The constituents of the model implements the
		// ICloneable interface. This model provides
		// three methods:
		// * startCloneSession() is somewhat equivallent to a shallow
		//   copy of the constituent. After this protocol is executed,
		//   it is guaranteed that all constituents have been
		//   shallow-copied. No assumption is made about the link among
		//   constituents.
		// * performCloneSession() updates the links among constituents,
		//   using the isCloned() and getClone() methods. After this
		//   protocol is executed, it is guarenteed that all the links
		//   have been updated, somewhat like a deep copy;
		// * endCloneSession() finished the updates and cleans the possible
		//   temporary values, mainly it sets to null all the "clone"
		//   instance variable.

		final AbstractLevelModel clonedModel =
			(AbstractLevelModel) super.clone();

		// Yann 2002/04/08: Clone!
		// The cloned model must have its own instance
		// of class ArrayList for the list or Entities.
		clonedModel.resetListOfActors();

		this.clone(clonedModel);

		return clonedModel;
	}
	public final String generate(final IGenerator builder) {
		builder.open(this);

		final Iterator iterator = this.getIteratorOnActors();
		while (iterator.hasNext()) {
			((IConstituent) iterator.next()).accept(builder);
		}

		builder.close(this);
		return builder.getCode();
	}
	public IFactory getFactory() {
		return this.factory;
	}
	public void setFactory(final IFactory aFactory) {
		this.factory = aFactory;
	}
	public String toString() {
		final StringBuffer buffer = new StringBuffer();
		final Iterator iterator = this.getIteratorOnActors();
		while (iterator.hasNext()) {
			buffer.append(iterator.next().toString());
			if (iterator.hasNext()) {
				buffer.append('\n');
			}
		}
		return buffer.toString();
	}
	public final Object walk(final IWalker walker) {
		walker.open(this);

		// Yann 2004/12/19: Comodification again...
		// I prevent comodification exceptions by iterating
		// "by hand" over the list of entities.
		//	final Iterator iterator = this.listOfActors().iterator();
		//	while (iterator.hasNext()) {
		//		((IConstituent) iterator.next()).accept(walker);
		//	}
		// Yann 2005/10/12: Iterator!
		// I now provide iterators to go through a list of actors
		// rather than using the depracated (and soon to disappear)
		// listOfActors() method. So, I also provide an iterator
		// iterating over a copy of the list, thus allowing concurrent
		// modifications.
		//	final List listOfActors = this.listOfActors();
		//	for (int i = 0; i < listOfActors.size(); i++) {
		//		((IConstituent) listOfActors.get(i)).accept(walker);
		//	}
		final Iterator iterator = this.getIteratorOnConcurrentActors();
		while (iterator.hasNext()) {
			((IConstituent) iterator.next()).accept(walker);
		}

		walker.close(this);
		return walker.getResult();
	}
	protected void clone(final IAbstractLevelModel anAbstractLevelModel) {
		// First, I make a shallow copy of all the entities.
		Iterator iterator = this.getIteratorOnActors();
		while (iterator.hasNext()) {
			final IConstituent constituent = (IConstituent) iterator.next();
			constituent.startCloneSession();
			try {
				anAbstractLevelModel.addActor(constituent.getClone());
			}
			catch (final ModelDeclarationException pde) {
				pde.printStackTrace(Output.getInstance().errorOutput());
			}
		}

		// Second, I update the links among entities (deep copy).
		iterator = this.getIteratorOnActors();
		while (iterator.hasNext()) {
			((IConstituent) iterator.next()).performCloneSession();
		}

		// Finally, I clean up all temporary instance variable.
		iterator = this.getIteratorOnActors();
		while (iterator.hasNext()) {
			((IConstituent) iterator.next()).endCloneSession();
		}
	}
}
