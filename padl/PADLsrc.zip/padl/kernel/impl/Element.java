/*
 * (c) Copyright 2001, 2002 Herv� Albin-Amiot and Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * Soft-Maint S.A.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

/*
 * Classe Element used for type checking and the "attached" protocol.
 * In this protocol, delegation is used instead of bound properties in order to
 * retablish element in its previous state, when detachment occurs...
 * (even if the protocol provides events propagation). 
 */

import padl.kernel.IElement;
import padl.kernel.exception.ModelDeclarationException;
import util.multilingual.MultilingualManager;

abstract class Element extends Constituent implements IElement {
	private IElement attachedElement;

	public Element(final String actorID) {
		super(actorID);
	}
	public void attachTo(final IElement anElement)
		throws ModelDeclarationException {

		if (anElement != null) {
			if (anElement == this) {
				throw new ModelDeclarationException(
					MultilingualManager.getString(
						"ELEM_ATTACH",
						Element.class
					)
				);
			}

			if (!anElement.getClass().isInstance(this)) {
				throw new ModelDeclarationException(
					MultilingualManager.getString(
						"ATTACH",
						Element.class,
						new Object[]{anElement.getClass()}
					)
				);
			}

			this.detach();
			this.attachedElement = anElement;
		}
	}
	public void detach() {
		final IElement oldAttachedElement = this.getAttachedElement();

		if (oldAttachedElement == null) {
			return;
		}

		this.attachedElement = null;
	}
	public IElement getAttachedElement() {
		return this.attachedElement;
	}
	public String getName() {
		// Delegation is used...
		if (this.getAttachedElement() == null) {
			return super.getName();
		}
		return this.getAttachedElement().getName();
	}
	/**
	 * This methods is used by the clone protocol.
	 */
	public void performCloneSession() {
		if (this.getAttachedElement() != null) {
			((Element) this.getClone()).attachedElement =
				(Element) this.getAttachedElement().getClone();
		}

		super.performCloneSession();
	}
	public void startCloneSession() {
		super.startCloneSession();
		((Element) this.getClone()).attachedElement = null;
	}
}
