/*
 * (c) Copyright 2001, 2002 Herv� Albin-Amiot and Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * Soft-Maint S.A.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import padl.kernel.IClass;
import padl.kernel.IEntity;
import padl.kernel.IEntityMarker;
import padl.kernel.IInterface;
import padl.kernel.exception.ModelDeclarationException;
import util.multilingual.MultilingualManager;

import com.ibm.toad.cfparse.utils.Access;

class Class extends Entity implements IEntityMarker, IClass {
	private boolean forceAbstract = false;
	private List listOfSuperInterfaces = new ArrayList();

	public Class(final String anActorID) {
		super(anActorID);
	}
	// Yann 2004/08/15: Specialisation and implementation.
	// I want to unify the specialisation and implementation relationships
	// with other relationships. So, I don't treat as a special case the
	// inherited entity for classes.
	//	public Class(final String anActorID, final IEntity inheritedEntity) {
	//		super(anActorID);
	//		try {
	//			this.addInheritedActor(inheritedEntity);
	//		}
	//		catch (final ModelDeclarationException e) {
	//			// No error can occur
	//		}
	//	}
	// Yann 2002/07/29: Thought...
	// I think the following method is not consistent with the idea of
	// vetoable property. I guess a better implementation would be for
	// the PClass class to register itself as a listener on the list
	// of inherited entities and to veto any addition to the list when
	// the list already contains one entity.
	//	public void addInherits(final Entity aPEntity)
	//		throws ModelDeclarationException {
	//
	//		if (this.listOfInheritedEntities().size() > 0) {
	//			StringBuffer buffer = new StringBuffer();
	//			buffer.append("Only single inheritance supported for class\n");
	//			buffer.append(this);
	//			buffer.append(" -|>- ");
	//			buffer.append(this.listOfInheritedEntities().(0));
	//			buffer.append("\nCannot attach new super-class\n");
	//			buffer.append(aPEntity);
	//			throw new ModelDeclarationException(buffer.toString());
	//		}
	//
	//		super.addInherits(aPEntity);
	//	}
	public void addImplementedActor(final IEntity anEntity)
		throws ModelDeclarationException {

		if (this.listOfSuperInterfaces.contains(anEntity)) {
			throw new ModelDeclarationException(
				MultilingualManager.getString(
					"ALREADY_IMPL",
					Class.class,
					new Object[]{anEntity.getID(), this.getID()}
				)
			);
		}

		this.listOfSuperInterfaces.add(anEntity);
		//	this.addActor(
		//		new Implementation("I" + anEntity.getActorID(), anEntity));

		 ((Entity) anEntity).addInheritingActor(this);
		//	anEntity.addActor(
		//		new Generalisation("G" + this.getActorID(), this));
	}
	public void assumeAllInterfaces() {
		try {
			final Iterator iterator = this.listOfSuperInterfaces.iterator();
			while (iterator.hasNext()) {
				this.assumeInterface((Interface) iterator.next());
			}
		}
		catch (final ModelDeclarationException e) {
			// No ModelDeclarationException can occur.
		}
	}
	public void assumeInterface(final IInterface anInterface)
		throws ModelDeclarationException {

		if (!this.listOfSuperInterfaces.contains(anInterface)) {
			throw new ModelDeclarationException(
				MultilingualManager.getString(
					"NOT_IMPL",
					Class.class,
					new Object[]{anInterface.getID(), this.getID()}
				)
			);
		}

		final Iterator iterator = anInterface.getIteratorOnActors();
		while (iterator.hasNext()) {
			try {
				final Element orgElement = (Element) iterator.next();
				orgElement.startCloneSession();
				final Element dupElement = (Element) orgElement.getClone();
				orgElement.endCloneSession();
				dupElement.setAbstract(false);
				dupElement.attachTo(orgElement);
				this.addActor(dupElement);
			}
			catch (final ModelDeclarationException e) {
				// In case of duplicated element.
			}
		}
	}
	public IEntity getImplementedActor(final String anEntityName) {
		final Iterator iterator = this.listOfImplementedActors().iterator();
		while (iterator.hasNext()) {
			final Entity implementedEntity = (Entity) iterator.next();
			if (implementedEntity.getName().equals(anEntityName)) {
				return implementedEntity;
			}
		}

		return null;
	}
	public boolean isForceAbstract() {
		return this.forceAbstract;
	}
	public List listOfImplementedActors() {
		return this.listOfSuperInterfaces;
	}
	public void performCloneSession() {
		super.performCloneSession();

		// Duplicate implementation hierarchy.
		final Class clonedPClass = (Class) this.getClone();
		clonedPClass.listOfSuperInterfaces =
			new ArrayList(this.listOfSuperInterfaces.size());
		final Iterator iterator = this.listOfSuperInterfaces.iterator();
		while (iterator.hasNext()) {
			final Entity currentInterface = (Entity) iterator.next();
			// Yann: The followind lines are not needed anymore?
			// if (currentPInterface.isCloned()) {
			// tmpObject.removeShouldImplement(currentPInterface);
			// try {
			// Yann 2001/07/31: Hack!
			// The following test is only needed when cloning
			// a subList of the model.
			// A better and *cleaner* algorithm must be
			// implemented eventually.
			if (currentInterface.getClone() != null) {
				clonedPClass.listOfSuperInterfaces.add(
					(Entity) currentInterface.getClone());
			}
		}
	}
	public void removeImplementedActor(final IEntity anEntity) {
		this.listOfSuperInterfaces.remove(anEntity);
	}
	public void setAbstract(final boolean aBoolean)
		throws ModelDeclarationException {

		forceAbstract = aBoolean;
		super.setAbstract(aBoolean);
	}
	public void setVisibility(final int visibility)
		throws ModelDeclarationException {

		super.setVisibility(
			isForceAbstract()
				? (visibility | Access.ACC_ABSTRACT)
				: visibility);
	}
	public String toString() {
		final StringBuffer codeEq = new StringBuffer();
		codeEq.append(super.toString());
		codeEq.append(" class ");
		codeEq.append(this.getName());
		if (this.listOfInheritedActors().size() > 0) {
			codeEq.append(" extends ");
			final Iterator iterator = this.listOfInheritedActors().iterator();
			while (iterator.hasNext()) {
				codeEq.append(((Entity) (iterator.next())).getName());
				if (iterator.hasNext()) {
					codeEq.append(", ");
				}
			}
		}
		if (this.listOfImplementedActors().size() > 0) {
			codeEq.append(" implements ");
			final Iterator enumaration = this.listOfSuperInterfaces.iterator();
			while (enumaration.hasNext()) {
				codeEq.append(((Entity) (enumaration.next())).getName());
				if (enumaration.hasNext()) {
					codeEq.append(", ");
				}
			}
		}
		return codeEq.toString();
	}
}
