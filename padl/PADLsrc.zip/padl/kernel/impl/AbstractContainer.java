/*
 * (c) Copyright 2001-2004 Yann-Ga�l Gu�h�neuc,
 * University of Montr�al.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the author, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN,
 * ANY LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHOR IS ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import padl.event.ElementEvent;
import padl.event.EntityEvent;
import padl.event.IModelListener;
import padl.kernel.IAbstractLevelModel;
import padl.kernel.IConstituent;
import padl.kernel.IContainer;
import padl.kernel.IElement;
import padl.kernel.IEntity;
import padl.kernel.IConstituentOfEntity;
import padl.kernel.IConstituentOfModel;
import padl.kernel.exception.ModelDeclarationException;
import padl.util.Util;

/**
 * @author Yann-Ga�l Gu�h�neuc
 * @since  2004/04/09
 */
abstract class AbstractContainer
	extends AbstractSubject
	implements IContainer {

	private List actorsIDCache = new ArrayList();
	private List actorsNameCache = new ArrayList();
	// Yann 2004/12/13: Performances
	// When loading huge AOL file, it seems that:
	//     this.doesContainActorWithID(aConstituent.getActorID())
	// is a performance bottleneck because of the many (maaany!)
	// instances of Iterator built. I cannot replace the list by a
	// hashtable which key is the actor ID because the list must be
	// sorted to ensure similar behavior on different platformes.
	// So, I cache the actor in a second list.
	private List listOfActors = new ArrayList();
	private int uniqueID;

	public void addActor(final IConstituent aConstituent)
		throws ModelDeclarationException {

		if (this.doesContainActorWithID(aConstituent.getID())) {
			final StringBuffer buffer = new StringBuffer();
			buffer.append("Duplicate actorID: ");
			buffer.append(aConstituent.getID());
			buffer.append(" (");
			buffer.append(aConstituent.getClass());
			buffer.append(") in ");
			buffer.append(this.getClass());
			throw new ModelDeclarationException(buffer.toString());
		}

		this.sortAndAddActor(aConstituent);
	}
	protected void addUniqueIDToEnclosedConstituent(final IConstituent aConstituent) {
		// Yann 2006/02/24: UniqueID...
		// I need a UniqueID for IMethodInvocation and IParemeter in IMethod
		// and for any IRelationship in IEntity. So, when using the method
		// concretelyAddActor(), I take care of the unique ID.

		if (this instanceof AbstractContainer
			&& aConstituent instanceof Constituent) {

			((Constituent) aConstituent).setID(
				aConstituent.getID() + '_' + this.uniqueID);
		}
	}
	private void broadcastAdditionOfConstituent(final IConstituent aConstituent) {
		// Yann 2004/04/09: Listener!
		// It is now the responsibility of this class to manage
		// the listeners and to send the appropriate events when
		// a change occurs.
		// Yann 2006/03/08: Listeners...
		// I recursively add the listeners to the constituent that I add...
		aConstituent.addModelListeners(this.getModelListeners());

		// Yann 2005/10/07: Packages!
		// I should distinguish among entities and packages...
		if (aConstituent instanceof IConstituentOfModel) {
			this.fireModelChange(
				IModelListener.ENTITY_ADDED,
				new EntityEvent(this, (IConstituentOfModel) aConstituent));
		}
		else if (aConstituent instanceof IConstituentOfEntity) {
			this.fireModelChange(
				IModelListener.ELEMENT_ADDED,
				new ElementEvent(this, (IConstituentOfEntity) aConstituent));
		}
	}
	protected void concretlyAddActor(final IConstituent aConstituent) {
		// Yann 2004/12/20: Test and order II!
		// This method is used to add method invocations to
		// constructors and methods only because method 
		// invocations must not be sorted.

		this.listOfActors.add(aConstituent);
		this.uniqueID++;
		// Yann 2004/12/13: Performances
		// I cache the actorID to improve performance
		// (to avoid creating instances of Iterator over and over again).
		this.actorsIDCache.add(aConstituent.getID());
		this.actorsNameCache.add(aConstituent.getName());
		this.broadcastAdditionOfConstituent(aConstituent);
	}
	protected void concretlyAddActorWithUniqueID(final IConstituent aConstituent) {
		// Yann 2006/02/24: UniqueID...
		// I need a UniqueID for IMethodInvocation and IParemeter in IMethod
		// and for any IRelationship in IEntity. So, when using the method
		// concretelyAddActor(), I take care of the unique ID.
		this.addUniqueIDToEnclosedConstituent(aConstituent);
		this.concretlyAddActor(aConstituent);
	}
	public boolean doesContainActorWithID(final String anID) {
		return this.getActorFromID(anID) != null;
	}
	public boolean doesContainActorWithName(final String aName) {
		return this.getActorFromName(aName) != null;
	}
	public IConstituent getActorFromID(final String anID) {
		// Yann 2004/12/13: Performances
		// I cached the actorID to improve performance
		// (to avoid creating instances of Iterator over and over again).
		// I can now you the cached value to give me the index of the
		// constituent in the list of actors.
		//	final Iterator iterator = this.listOfActors().iterator();
		//	while (iterator.hasNext()) {
		//		final IConstituent constituent = (IConstituent) iterator.next();
		//		if (constituent.getActorID().equals(anID)) {
		//			return constituent;
		//		}
		//	}
		//	return null;
		final int index = this.actorsIDCache.indexOf(anID);
		if (index > -1) {
			return (IConstituent) this.listOfActors.get(index);
		}
		else {
			return null;
		}
	}
	public IConstituent getActorFromName(final String aName) {
		// Yann 2007/11/21: Performances
		// I cached the actorName to improve performance
		// (to avoid creating instances of Iterator over and over again).
		// I can now you the cached value to give me the index of the
		// constituent in the list of actors.
		//	final Iterator iterator = this.getIteratorOnActors();
		//	while (iterator.hasNext()) {
		//		final IConstituent constituent = (IConstituent) iterator.next();
		//		if (constituent.getName().equals(aName)) {
		//			return constituent;
		//		}
		//	}
		//	return null;
		final int index = this.actorsNameCache.indexOf(aName);
		if (index > -1) {
			return (IConstituent) this.listOfActors.get(index);
		}
		else {
			return null;
		}
	}
	public Iterator getIteratorOnActors() {
		// Yann 2005/10/12: Iterator!
		// I replace the list with an iterator, but this
		// is a major bottleneck in some specific case!
		// TODO: Implement my own "smart" iterator which
		// could be tightly linked with the AbstractContainer
		// class to prevent too many memory allocation (Singleton).
		return this.listOfActors.iterator();
	}
	public Iterator getIteratorOnActors(
		final java.lang.Class aConstituentType) {

		// Yann 2005/10/12: Iterator!
		// I replace the list with an iterator, but this
		// is a major bottleneck in some specific case!
		// TODO: Implement my own "smart" iterator which
		// could be tightly linked with the AbstractContainer
		// class to prevent too many memory allocation (Singleton).
		return Util.getTypedConstituentsIterator(
			this.listOfActors,
			aConstituentType);
	}
	public Iterator getIteratorOnConcurrentActors() {
		// Yann 2005/10/12: Iterator!
		// I replace the list with an iterator, but this
		// is a major bottleneck in some specific case!
		// TODO: Implement my own "smart" iterator which
		// could be tightly linked with the AbstractContainer
		// class to prevent too many memory allocation (Singleton).
		// (The name of the method is deliberate for consistency
		// and also as a joke :-).)
		final IConstituent[] array =
			new IConstituent[this.listOfActors.size()];
		this.listOfActors.toArray(array);
		return Arrays.asList(array).iterator();
	}
	public Iterator getIteratorOnConcurrentActors(
		final java.lang.Class aConstituentType) {
		// Yann 2005/10/12: Iterator!
		// I replace the list with an iterator, but this
		// is a major bottleneck in some specific case!
		// TODO: Implement my own "smart" iterator which
		// could be tightly linked with the AbstractContainer
		// class to prevent too many memory allocation (Singleton).
		// (The name of the method is deliberate for consistency
		// and also as a joke :-).)
		final IConstituent[] array =
			new IConstituent[this.listOfActors.size()];
		this.listOfActors.toArray(array);
		return Util.getTypedConstituentsIterator(
			Arrays.asList(array),
			aConstituentType);
	}
	public int getNumberOfActors() {
		// Yann 2005/10/12: Iterator!
		// I replace the list with an iterator, but this
		// is a major bottleneck in some specific case!
		return this.listOfActors.size();
	}
	public int getNumberOfActors(final java.lang.Class aConstituentType) {
		// Duc-Loc 2006/01/25: Consistency
		final Iterator iterator =
			Util.getTypedConstituentsIterator(
				this.listOfActors,
				aConstituentType);

		int size = 0;
		while (iterator.hasNext()) {
			iterator.next();
			size++;
		}

		return size;
		// Ask Yann why getTypedConstituentsList() is set to private arrrggg!!!
		// Because, we don't want to give access to sensible information :-)
	}
	public int getUniqueID() {
		return this.uniqueID;
	}
	/**
	 * This method returns a list of all the
	 * actors (instances of Entity) added to
	 * 
	 * this model.
	 * 
	 * @deprecated This method is dangerous because it exposes the
	 * inner working of all the constituents that are able to contains
	 * other constituents. Thus, it is now replaced with the two
	 * getIterator() and getIterator(Class aConstituentType) methods
	 * (and related methods).
	 */
	public List listOfActors() {
		return this.listOfActors;
	}
	private final void removeActorFromID(final IConstituent aConstituent) {
		this.listOfActors.remove(aConstituent);
		this.actorsIDCache.remove(aConstituent.getID());
		this.actorsNameCache.remove(aConstituent.getName());

		// Yann 2004/04/09: Listener!
		// It is now the responsibility of this class to manage
		// the listeners and to send the appropriate events when
		// a change occurs.
		if (this instanceof IAbstractLevelModel) {
			this.fireModelChange(
				IModelListener.ENTITY_REMOVED,
				new EntityEvent(
					(IAbstractLevelModel) this,
					(IEntity) aConstituent));
		}
		else if (this instanceof IEntity) {
			this.fireModelChange(
				IModelListener.ELEMENT_REMOVED,
				new ElementEvent((IEntity) this, (IElement) aConstituent));
		}
	}
	public void removeActorFromID(final String anID) {
		this.removeActorFromID((IConstituent) this.getActorFromID(anID));
	}
	public void removeAllActors() {
		// Yann 2002/04/06: Java collection library...
		// The Collection implementated in the JDK is "fail-fast".
		// It means that you cannot use an iterator on a collection
		// and modify the collection as you use the iterator.
		// Thus, I cannot iterate (using an iterator) over the
		// collection of PEntities to remove all them! 
		while (this.listOfActors.size() > 0) {
			this.removeActorFromID((IConstituent) this.listOfActors.get(0));
		}
	}
	public void resetListOfActors() {
		// Yann 2004/04/09: Clone!
		// I make sure that a clone of an abstract level
		// model gets a new instance of an array list.
		// (See also method AbstractLevelModel.clone().)
		this.listOfActors = new ArrayList();
		this.actorsIDCache = new ArrayList();
		this.actorsNameCache = new ArrayList();
	}
	private void sortAndAddActor(final IConstituent aConstituent) {
		// Yann 2004/04/09: Test and order!
		// Actors are given in a different order on Linux and
		// on Windows. I sort them to ensure that tests run
		// similartly acorss platforms. 
		// this.listOfActors.add(aConstituent);
		int index = 0;
		final int size = this.listOfActors.size();
		final String constituentID = aConstituent.getID();
		while (index < size
			&& ((IConstituent) this.listOfActors.get(index)).getID().compareTo(
				constituentID)
				< 0) {
			index++;
		}

		this.listOfActors.add(index, aConstituent);
		this.uniqueID++;
		// Yann 2004/12/13: Performances
		// I cache the actorID to improve performance
		// (to avoid creating instances of Iterator over and over again).
		this.actorsIDCache.add(index, aConstituent.getID());
		this.actorsNameCache.add(index, aConstituent.getName());
		this.broadcastAdditionOfConstituent(aConstituent);
	}
	protected void sortAndAddActorWithUniqueID(final IConstituent aConstituent) {
		// Yann 2006/02/24: UniqueID...
		// I need a UniqueID for IMethodInvocation and IParemeter in IMethod
		// and for any IRelationship in IEntity. So, when using the method
		// concretelyAddActor(), I take care of the unique ID.
		this.addUniqueIDToEnclosedConstituent(aConstituent);
		this.sortAndAddActor(aConstituent);
	}
}