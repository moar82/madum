/*
 * (c) Copyright 2001, 2002 Herv� Albin-Amiot and Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * Soft-Maint S.A.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

import padl.kernel.ICodeLevelModel;
import padl.kernel.ICodeLevelModelCreator;
import padl.kernel.IConstituent;
import padl.kernel.IEntity;
import padl.kernel.IIdiomLevelModel;
import padl.kernel.IPackage;
import padl.kernel.exception.CreationException;
import padl.kernel.exception.ModelDeclarationException;
import util.multilingual.MultilingualManager;

/**
 * @author Yann-Ga�l Gu�h�neuc
 * @since  2005/08/05
 */
class CodeLevelModel
	extends AbstractLevelModel
	implements ICodeLevelModel, Cloneable {

	private String modelName;

	public CodeLevelModel() {
		this("CodeLevelModel");
	}
	public CodeLevelModel(final String modelName) {
		this.modelName = modelName;
	}
	public void addActor(final IConstituent aConstituent)
		throws ModelDeclarationException {

		if (aConstituent instanceof IEntity) {
			this.addActor((IEntity) aConstituent);
		}
		else if (aConstituent instanceof IPackage) {
			this.addActor((IPackage) aConstituent);
		}
		else {
			throw new ModelDeclarationException(
				MultilingualManager.getString(
					"ENT_ADD_ORG_LEVEL",
					CodeLevelModel.class));
		}
	}
	public void addActor(final IEntity anEntity)
		throws ModelDeclarationException {

		super.addActor(anEntity);
	}
	public void addActor(final IPackage aPackage)
		throws ModelDeclarationException {

		super.addActor(aPackage);
	}
	public void create(final ICodeLevelModelCreator aCodeLevelCreator)
		throws CreationException {

		aCodeLevelCreator.create(this);
	}
	public String getName() {
		return this.modelName;
	}
	public IIdiomLevelModel convert(final String aName) {
		final IIdiomLevelModel idiomLevelModel =
			Factory.getInstance().createIdiomLevelModel(aName);

		this.clone(idiomLevelModel);

		return idiomLevelModel;
	}
}