/*
 * (c) Copyright 2000-2002 Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes and Object Technology International, Inc.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * Yann-Ga�l Gu�h�neuc, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF YANN-GAEL GUEHENEUC IS ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import padl.kernel.IAbstractMethod;
import padl.kernel.IEntity;
import padl.kernel.IField;
import padl.kernel.IMethodInvocation;
import util.lang.Modifier;

/**
 * @author 	Yann-Ga�l Gu�h�neuc
 * @since	2002/08/19
 */
class MethodInvocation extends Element implements IMethodInvocation {
	private IAbstractMethod calledMethod;
	// Farouk Zaidi 2004/02/20: Fields added
	// Farouk Zaidi 2004/04/02: Modification.
	// "callingField" becomes an array of fields.
	private List callingFields = new ArrayList();
	private final int cardinality;
	private IEntity entityDeclaringField;
	private IEntity targetEntity;
	private final int type;
	private final int visibility;
	// Farouk 2004/03/23: Constructor.
	// Constructor for my needs, i.e., no cardinality and no type
	//
	// Question: How could the target entity be null?
	//	public MethodInvocation(
	//		final IEntity originEntity,
	//		final IEntity targetEntity,
	//		final IEntity entityDeclaringField) {
	//
	//		super(originEntity.getName() + COUNTER++ +":");
	//		this.originEntity = originEntity;
	//		this.targetEntity = targetEntity;
	//		this.entityDeclaringField = entityDeclaringField;
	//		this.type = -1;
	//		this.cardinality = 1;
	//	}
	// Yann 2004/08/02: Cleaning.
	// I modified the constructors to make them consistent
	// and to add the enclosing method (the enclosing method
	// and entity should be removed later, there should not
	// appear at all!)
	public MethodInvocation(
		final int type,
		final int cardinality,
		final int visibility,
		final IEntity targetEntity) {

		this(type, cardinality, visibility, targetEntity, null);
	}
	public MethodInvocation(
		final int type,
		final int cardinality,
		final int visibility,
		final IEntity targetEntity,
		final IEntity entityDeclaringField) {

		super("Method Invocation");

		this.type = type;
		this.cardinality = cardinality;
		this.visibility = visibility;
		this.targetEntity = targetEntity;
		this.entityDeclaringField = entityDeclaringField;
	}
	public void addCallingField(final IField field) {
		this.callingFields.add(field);
	}
	public boolean equals(final IMethodInvocation messageType) {
		return this.getTargetEntity() == messageType.getTargetEntity()
			&& this.getType() == messageType.getType();
	}
	public boolean equals(final Object object) {
		if (object instanceof IMethodInvocation) {
			return this.equals((IMethodInvocation) object);
		}
		return super.equals(object);
	}
	// St�phane 2005/12/06: Equals!	
	/**
	 * Method to calculate a correct hashCode to work with equals(Object)
	 * @return hashCode based on targetEntity and type of invocation
	 * @see padl.kernel.impl.Constituent#hashCode()
	 */
	public int hashCode() {
		int hashCode = this.getType();

		final IEntity targetEntity = this.getTargetEntity();
		// If target is not null, we can use it to better hash the instances
		if (targetEntity != null) {
			hashCode += 31 * targetEntity.hashCode();
		}
		return hashCode;
	}
	public IAbstractMethod getCalledMethod() {
		return this.calledMethod;
	}
	public int getCardinality() {
		return this.cardinality;
	}
	public IEntity getFieldDeclaringEntity() {
		return this.entityDeclaringField;
	}
	public IField getFirstCallingField() {
		return (IField) callingFields.get(0);
	}
	public String getName() {
		final String fieldName;
		final String entityDeclaringFieldName;
		final String invokedMethodName;
		final String targetEntityName;

		if (this.callingFields != null) {
			if (this.callingFields.size() > 0) {

				final StringBuffer buffer = new StringBuffer();
				final Iterator iterator = this.callingFields.iterator();
				while (iterator.hasNext()) {
					final IField element = (IField) iterator.next();
					buffer.append(element.getName());
					if (iterator.hasNext()) {
						buffer.append(".");
					}
				}
				fieldName = buffer.toString();
			}
			else {
				fieldName = "NoField";
			}
		}
		else {
			fieldName = "NoField";
		}
		if (this.entityDeclaringField == null) {
			entityDeclaringFieldName = "NoFieldEntity";
		}
		else {
			entityDeclaringFieldName = this.entityDeclaringField.getName();
		}
		if (this.calledMethod == null) {
			invokedMethodName = "NoMethod";
		}
		else {
			invokedMethodName = this.calledMethod.getName();
		}
		if (this.targetEntity == null) {
			targetEntityName = "NoTarget";
		}
		else {
			targetEntityName = this.targetEntity.getName();
		}

		final StringBuffer buffer = new StringBuffer();
		buffer.append(fieldName);
		buffer.append(':');
		buffer.append(entityDeclaringFieldName);
		buffer.append(':');
		buffer.append(invokedMethodName);
		buffer.append(':');
		buffer.append(targetEntityName);
		return buffer.toString();
	}
	public IEntity getTargetEntity() {
		return this.targetEntity;
	}
	public int getType() {
		return this.type;
	}
	public int getVisibility() {
		return this.visibility;
	}
	public List listCallingFields() {
		return this.callingFields;
	}
	/**
	 * This methods is used by the clone protocol.
	 */
	public void performCloneSession() {
		final MethodInvocation clonedMethodInvocation =
			(MethodInvocation) this.getClone();

		// Yann 2005/08/05: Method invocation!
		// The called method of a method invocation can be null!?
		if (this.calledMethod != null) {
			// Yann 2007/11/13: Cloning...
			// Should this test be there?
			if (this.calledMethod.getClone() == null) {
				this.calledMethod.startCloneSession();
				this.calledMethod.performCloneSession();
			}
			clonedMethodInvocation.calledMethod =
				(IAbstractMethod) this.calledMethod.getClone();
		}

		// Yann 2007/11/13: Same reference!
		// I cannot use the clear() method here because
		// both the original and the clone point on the
		// same list!!!
		//	clonedMethodInvocation.callingFields.clear();
		clonedMethodInvocation.callingFields = new Vector();
		final Iterator iterator = this.callingFields.iterator();
		while (iterator.hasNext()) {
			final IField field = (IField) iterator.next();
			// Yann 2007/11/13: Cloning...
			// Should this test be there?
			if (field.getClone() == null) {
				field.startCloneSession();
				field.performCloneSession();
			}
			((MethodInvocation) this.getClone()).callingFields.add(
				field.getClone());
		}

		if (this.entityDeclaringField != null) {
			clonedMethodInvocation.entityDeclaringField =
				(IEntity) this.entityDeclaringField.getClone();
		}

		if (this.targetEntity != null) {
			clonedMethodInvocation.targetEntity =
				(IEntity) this.targetEntity.getClone();
		}
	}
	public void setCalledMethod(final IAbstractMethod calledMethod) {
		this.calledMethod = calledMethod;
	}
	public void setCallingField(final List callingFields) {
		this.callingFields = callingFields;
	}
	public String toString() {
		final String fieldName;
		final String entityDeclaringFieldName;
		final String invokedMethodName;
		final String targetEntityName;

		if (this.callingFields != null) {
			if (this.callingFields.size() > 0) {

				final StringBuffer buffer = new StringBuffer();
				final Iterator iterator = this.callingFields.iterator();
				while (iterator.hasNext()) {
					final IField element = (IField) iterator.next();
					buffer.append(element.getName());
					if (iterator.hasNext()) {
						buffer.append(".");
					}
				}
				fieldName = buffer.toString();
			}
			else {
				fieldName = "No field name";
			}
		}
		else {
			fieldName = "No field name";
		}
		if (this.entityDeclaringField == null) {
			entityDeclaringFieldName = "No declaring entity";
		}
		else {
			entityDeclaringFieldName = this.entityDeclaringField.getName();
		}
		if (this.calledMethod == null) {
			invokedMethodName = "No method invoked";
		}
		else {
			invokedMethodName = this.calledMethod.getName();
		}
		if (this.targetEntity == null) {
			targetEntityName = "No target entity";
		}
		else {
			targetEntityName = this.targetEntity.getName();
		}

		final StringBuffer buffer = new StringBuffer();
		buffer.append("Field name      : ");
		buffer.append(fieldName);
		buffer.append("\nDeclaring entity: ");
		buffer.append(entityDeclaringFieldName);
		buffer.append("\nMethod invoked  : ");
		buffer.append(invokedMethodName);
		buffer.append("\nTarget entity   : ");
		buffer.append(targetEntityName);
		buffer.append("\nVisibility      : ");
		buffer.append(Modifier.toString(this.getVisibility()));
		buffer.append("\nCadinality      : ");
		buffer.append(this.getCardinality());
		buffer.append('\n');
		return buffer.toString();
	}
}
