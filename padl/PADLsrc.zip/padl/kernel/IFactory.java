/*
 * (c) Copyright 2001-2003 Yann-Ga�l Gu�h�neuc,
 * �cole des Mines de Nantes and Object Technology International, Inc.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the author, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN,
 * ANY LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHOR IS ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.kernel;

import padl.kernel.exception.ModelDeclarationException;

/**
 * @author Yann-Ga�l Gu�h�neuc
 * @since  2003/12/05
 */
public interface IFactory {
	IAggregation createAggregationRelationship(
		final String aName,
		final IEntity aTargetEntity,
		final int aCardinality)
		throws ModelDeclarationException;
	IAssociation createAssociationRelationship(
		final String aName,
		final IEntity aTargetEntity,
		final int aCardinality)
		throws ModelDeclarationException;
	IClass createClass(final String aName) throws ModelDeclarationException;
	ICodeLevelModel createCodeLevelModel(final String aName);
	IComposition createCompositionRelationship(final IAssociation anAssociation)
		throws ModelDeclarationException;
	IComposition createCompositionRelationship(
		final String aName,
		final IEntity aTargetEntity,
		final int aCardinality)
		throws ModelDeclarationException;
	IConstructor createConstructor(final String aName)
		throws ModelDeclarationException;
	IContainerAggregation createContainerAggregationRelationship(
		final String aName,
		final IEntity aTargetEntity,
		final int aCardinality)
		throws ModelDeclarationException;
	IContainerComposition createContainerCompositionRelationship(final IAssociation anAssociation)
		throws ModelDeclarationException;
	IContainerComposition createContainerCompositionRelationship(
		final String aName,
		final IEntity aTargetEntity,
		final int aCardinality)
		throws ModelDeclarationException;
	ICreation createCreationRelationship(
		final String aName,
		final IEntity aTargetEntity,
		final int aCardinality)
		throws ModelDeclarationException;
	IDelegatingMethod createDelegatingMethod(
		final String aName,
		final IAssociation aTargetAssociation)
		throws ModelDeclarationException;
	IDelegatingMethod createDelegatingMethod(
		final String aName,
		final IAssociation aTargetAssociation,
		final IMethod aSupportMethod)
		throws ModelDeclarationException;
	IDesignLevelModel createDesignLevelModel(final String aName);
	IField createField(
		final String aName,
		final String aType,
		final int aCardinality)
		throws ModelDeclarationException;
	IGetter createGetter(final IMethod aMethod)
		throws ModelDeclarationException;
	IGetter createGetter(final String aName)
		throws ModelDeclarationException;
	IGhost createGhost(final String aName) throws ModelDeclarationException;
	IIdiomLevelModel createIdiomLevelModel(final String aName);
	IInterface createInterface(final String aName)
		throws ModelDeclarationException;
	IMemberClass createMemberClass(final String aName)
		throws ModelDeclarationException;
	IMemberGhost createMemberGhost(final String aName)
		throws ModelDeclarationException;
	IMemberInterface createMemberInterface(final String aName)
		throws ModelDeclarationException;
	IMethod createMethod(final String aName)
		throws ModelDeclarationException;
	IMethodInvocation createMethodInvocation(
		final int type,
		final int cardinality,
		final int visibility,
		final IEntity targetEntity)
		throws ModelDeclarationException;
	IMethodInvocation createMethodInvocation(
		final int type,
		final int cardinality,
		final int visibility,
		final IEntity targetEntity,
		final IEntity entityDeclaringField)
		throws ModelDeclarationException;
	IPackage createPackage(final String aName)
		throws ModelDeclarationException;
	IParameter createParameter(final String aType)
		throws ModelDeclarationException;
	IParameter createParameter(final String aName, final String aType)
		throws ModelDeclarationException;
	ISetter createSetter(final IMethod aMethod)
		throws ModelDeclarationException;
	ISetter createSetter(final String aName)
		throws ModelDeclarationException;
	IUseRelationship createUseRelationship(
		final String aName,
		final IEntity aTargetEntity,
		final int aCardinality)
		throws ModelDeclarationException;
}
