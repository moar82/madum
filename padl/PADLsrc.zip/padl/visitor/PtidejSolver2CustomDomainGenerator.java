/*
 * (c) Copyright 2001, 2002 Herv� Albin-Amiot and Yann-Ga�l Gu�h�neuc,
 * Ecole des Mines de Nantes
 * Object Technology International, Inc.
 * Soft-Maint S.A.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the authors, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN, ANY
 * LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHORS ARE ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package padl.visitor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import padl.kernel.IAbstractLevelModel;
import padl.kernel.IAbstractModel;
import padl.kernel.IAggregation;
import padl.kernel.IAssociation;
import padl.kernel.IClass;
import padl.kernel.IComposition;
import padl.kernel.IConstructor;
import padl.kernel.IContainerAggregation;
import padl.kernel.IContainerComposition;
import padl.kernel.ICreation;
import padl.kernel.IDelegatingMethod;
import padl.kernel.IDesignMotif;
import padl.kernel.IEntity;
import padl.kernel.IField;
import padl.kernel.IGetter;
import padl.kernel.IGhost;
import padl.kernel.IInterface;
import padl.kernel.IMemberClass;
import padl.kernel.IMemberGhost;
import padl.kernel.IMemberInterface;
import padl.kernel.IMethod;
import padl.kernel.IMethodInvocation;
import padl.kernel.IPackage;
import padl.kernel.IParameter;
import padl.kernel.ISetter;
import padl.kernel.IUseRelationship;
import padl.kernel.IWalker;

public class PtidejSolver2CustomDomainGenerator
	extends PtidejSolverDomainGenerator
	implements IWalker {

	private StringBuffer buffer = new StringBuffer(0);
	private List listOfAggregations = new ArrayList(0);
	private List listOfAssociations = new ArrayList(0);
	private List listOfCompositions = new ArrayList(0);
	private List listOfContainerAggregations = new ArrayList(0);
	private List listOfContainerCompositions = new ArrayList(0);
	private List listOfCreations = new ArrayList(0);
	private List listOfUses = new ArrayList(0);

	private IEntity[] pEntities;

	private boolean belongsToDomain(final String name) {
		for (int i = 0; i < this.pEntities.length; i++) {
			if (pEntities[i].getName().equals(name)) {
				return true;
			}
		}
		return false;
	}
	public void close(final IAbstractLevelModel p) {
		this.close((IAbstractModel) p);
	}
	private void close(final IAbstractModel p) {
		this.buffer.append("\nlistOfEntities: ");
		this.buffer.append(this.getListDeclaration());
		this.buffer.append(" := ");
		this.buffer.append(this.getListPrefix());
		// Yann 2005/10/07: Packages!
		// A model may now contrain entities and packages.
		// Yann 2005/10/12: Iterator!
		// I have now an iterator able to iterate over a
		// specified type of constituent of a list.
		final Iterator iterator = p.getIteratorOnActors(IEntity.class);
		while (iterator.hasNext()) {
			final IEntity entity = (IEntity) iterator.next();
			this.buffer.append(
				PtidejSolverDomainGenerator.convertToClaireIdentifier(
					entity.getName()));
			if (iterator.hasNext()) {
				this.buffer.append(", ");
			}
		}
		this.buffer.append(this.getListSuffix());
		this.buffer.append("");
	}
	public void close(final IClass p) {
		// Yann 2002/08/09: Copies!
		// I create an intermediate List to hold 
		// both superclasses and superinterfaces.
		final List superEntities = new ArrayList(p.listOfInheritedActors());
		final Iterator iterator = p.listOfImplementedActors().iterator();
		while (iterator.hasNext()) {
			superEntities.add(iterator.next());
		}
		this.close(p.getName(), superEntities);
	}
	public void close(final IConstructor aConstructor) {
	}
	public void close(final IDelegatingMethod aDelegatingMethod) {
	}
	public void close(final IDesignMotif p) {
		this.close((IAbstractModel) p);
	}
	public void close(final IGetter aGetter) {
	}
	public void close(final IGhost p) {
		this.close(p.getName(), p.listOfInheritedActors());
	}
	public void close(final IInterface p) {
		this.close(p.getName(), p.listOfInheritedActors());
	}
	public void close(final IMemberClass p) {
		this.close(p.getName(), p.listOfInheritedActors());
	}
	public void close(final IMemberGhost p) {
		this.close(p.getName(), p.listOfInheritedActors());
	}
	public void close(final IMemberInterface p) {
		this.close(p.getName(), p.listOfInheritedActors());
	}
	public void close(final IMethod aMethod) {
	}
	public void close(final IPackage p) {
	}
	public void close(final ISetter aSetter) {
	}
	private void close(final String name, final List listInherits) {
		final String claireIdentifier =
			PtidejSolverDomainGenerator.convertToClaireIdentifier(name);

		this.buffer.insert(
			0,
			claireIdentifier
				+ ":Entity := Entity(name = \""
				+ name
				+ "\")\n");
		this.buffer.append('\n');
		this.buffer.append('(');
		this.buffer.append(claireIdentifier);
		this.buffer.append(".superEntities := ");
		this.buffer.append(this.getListPrefix());
		Iterator iterator = listInherits.iterator();
		while (iterator.hasNext()) {
			this.buffer.append(
				PtidejSolverDomainGenerator.convertToClaireIdentifier(
					((IEntity) (iterator.next())).getName()));
			if (iterator.hasNext()) {
				this.buffer.append(", ");
			}
		}
		this.buffer.append(this.getListSuffix());
		this.buffer.append(",\n ");

		// Aggregation.
		final StringBuffer temporaryBuffer = new StringBuffer();
		iterator = this.listOfAggregations.iterator();
		while (iterator.hasNext()) {
			temporaryBuffer.append((String) iterator.next());
			if (iterator.hasNext()) {
				temporaryBuffer.append(", ");
			}
		}
		this.buffer.append(claireIdentifier);
		this.buffer.append(".aggregatedEntities := ");
		this.buffer.append(this.getListPrefix());
		this.buffer.append(temporaryBuffer.toString());
		this.buffer.append(this.getListSuffix());
		this.buffer.append(",\n ");

		// Association.
		temporaryBuffer.setLength(0);
		iterator = this.listOfAssociations.iterator();
		while (iterator.hasNext()) {
			temporaryBuffer.append((String) iterator.next());
			if (iterator.hasNext()) {
				temporaryBuffer.append(", ");
			}
		}
		this.buffer.append(claireIdentifier);
		this.buffer.append(".associatedEntities := ");
		this.buffer.append(this.getListPrefix());
		this.buffer.append(temporaryBuffer.toString());
		this.buffer.append(this.getListSuffix());
		this.buffer.append(",\n ");

		// Composition.
		this.buffer.append(claireIdentifier);
		this.buffer.append(".componentsType := ");
		this.buffer.append(this.getListPrefix());

		temporaryBuffer.setLength(0);
		iterator = this.listOfCompositions.iterator();
		while (iterator.hasNext()) {
			// final Entity pEntity = (Entity) iterator.next();
			final String pEntityName = (String) iterator.next();
			this.buffer.append(pEntityName);

			temporaryBuffer.append(this.getListPrefix());
			// Yann 2001/07/11: Too much!
			// This was too much: The Composition constraint had to many
			// Entity to play with, I only keep the Entity corresponding
			// to the target of the Composition link. The subclasses will
			// be dealt with through the StrictInheritance or
			// InheritancePath constraints.
			/* 
			Enumeration s =
			    PaLMGenerator.directSubclassesOf(pEntity, this.pEntities).elements();
			while (s.hasMoreElements()) {
			    pEntity = (Entity) s.nextElement();
			    components.append(PaLMGenerator.convertToClaireIdentifier(pEntity.getName()));
			    if (s.hasMoreElements()) {
			        components.append(", ");
			    }
			}
			*/
			temporaryBuffer.append(pEntityName);
			temporaryBuffer.append(this.getListSuffix());

			if (iterator.hasNext()) {
				this.buffer.append(", ");
				temporaryBuffer.append(", ");
			}
		}
		this.buffer.append(this.getListSuffix());
		this.buffer.append(",\n ");
		this.buffer.append(claireIdentifier);
		this.buffer.append(".composedEntities := ");
		this.buffer.append(this.getListOfListPrefix());
		this.buffer.append(temporaryBuffer.toString());
		this.buffer.append(this.getListOfListSuffix());
		this.buffer.append(",\n ");

		// ContainerAggregation.
		temporaryBuffer.setLength(0);
		iterator = this.listOfContainerAggregations.iterator();
		while (iterator.hasNext()) {
			temporaryBuffer.append((String) iterator.next());
			if (iterator.hasNext()) {
				temporaryBuffer.append(", ");
			}
		}
		this.buffer.append(claireIdentifier);
		this.buffer.append(".containerAggregatedEntities := ");
		this.buffer.append(this.getListPrefix());
		this.buffer.append(temporaryBuffer.toString());
		this.buffer.append(this.getListSuffix());
		this.buffer.append(",\n ");

		// ContainerComposition.
		this.buffer.append(claireIdentifier);
		this.buffer.append(".containerComponentsType := ");
		this.buffer.append(this.getListPrefix());

		temporaryBuffer.setLength(0);
		iterator = this.listOfContainerCompositions.iterator();
		while (iterator.hasNext()) {
			// final Entity pEntity = (Entity) iterator.next();
			final String pEntityName = (String) iterator.next();
			this.buffer.append(pEntityName);

			temporaryBuffer.append(this.getListPrefix());
			// Yann 2001/07/11: Too much!
			// This was too much: The Composition constraint had to many
			// Entity to play with, I only keep the Entity corresponding
			// to the target of the Composition link. The subclasses will
			// be dealt with through the StrictInheritance or
			// InheritancePath constraints.
			/* 
			Enumeration s =
			    PaLMGenerator.directSubclassesOf(pEntity, this.pEntities).elements();
			while (s.hasMoreElements()) {
			    pEntity = (Entity) s.nextElement();
			    components.append(PaLMGenerator.convertToClaireIdentifier(pEntity.getName()));
			    if (s.hasMoreElements()) {
			        components.append(", ");
			    }
			}
			*/
			temporaryBuffer.append(pEntityName);
			temporaryBuffer.append(this.getListSuffix());

			if (iterator.hasNext()) {
				this.buffer.append(", ");
				temporaryBuffer.append(", ");
			}
		}
		this.buffer.append(this.getListSuffix());
		this.buffer.append(",\n ");
		this.buffer.append(claireIdentifier);
		this.buffer.append(".containerComposedEntities := ");
		this.buffer.append(this.getListOfListPrefix());
		this.buffer.append(temporaryBuffer.toString());
		this.buffer.append(this.getListOfListSuffix());
		this.buffer.append(",\n ");

		// Known entities.
		temporaryBuffer.setLength(0);
		iterator = this.listOfUses.iterator();
		while (iterator.hasNext()) {
			temporaryBuffer.append((String) iterator.next());
			if (iterator.hasNext()) {
				temporaryBuffer.append(", ");
			}
		}
		this.buffer.append(claireIdentifier);
		this.buffer.append(".knownEntities := ");
		this.buffer.append(this.getListPrefix());
		this.buffer.append(temporaryBuffer.toString());
		this.buffer.append(this.getListSuffix());
		this.buffer.append(",\n ");

		// Created entities.
		temporaryBuffer.setLength(0);
		iterator = this.listOfCreations.iterator();
		while (iterator.hasNext()) {
			temporaryBuffer.append((String) iterator.next());
			if (iterator.hasNext()) {
				temporaryBuffer.append(", ");
			}
		}
		this.buffer.append(claireIdentifier);
		this.buffer.append(".createdEntities := ");
		this.buffer.append(this.getListPrefix());
		this.buffer.append(temporaryBuffer.toString());
		this.buffer.append(this.getListSuffix());
		this.buffer.append(",\n ");

		// Unknown entities.
		// I need to treat the first one as a "special" case,
		// because I don't know if I will have another
		// unknown entity after this first one.
		temporaryBuffer.setLength(0);
		boolean firstDone = false;
		int i = 0;
		for (; i < this.pEntities.length && !firstDone; i++) {
			String entityName =
				PtidejSolverDomainGenerator.convertToClaireIdentifier(
					this.pEntities[i].getName());

			if (!entityName.equals(claireIdentifier)
				&& !this.listOfAggregations.contains(entityName)
				&& !this.listOfAssociations.contains(entityName)
				&& !this.listOfCompositions.contains(entityName)
				&& !this.listOfContainerAggregations.contains(entityName)
				&& !this.listOfContainerCompositions.contains(entityName)
				&& !this.listOfCreations.contains(entityName)
				&& !this.listOfUses.contains(entityName)) {

				temporaryBuffer.append(entityName);

				firstDone = true;
			}
		}
		for (; i < this.pEntities.length; i++) {
			String entityName =
				PtidejSolverDomainGenerator.convertToClaireIdentifier(
					this.pEntities[i].getName());

			if (!entityName.equals(claireIdentifier)
				&& !this.listOfAggregations.contains(entityName)
				&& !this.listOfAssociations.contains(entityName)
				&& !this.listOfCompositions.contains(entityName)
				&& !this.listOfContainerAggregations.contains(entityName)
				&& !this.listOfContainerCompositions.contains(entityName)
				&& !this.listOfCreations.contains(entityName)
				&& !this.listOfUses.contains(entityName)) {

				temporaryBuffer.append(", ");
				temporaryBuffer.append(entityName);
			}
		}
		this.buffer.append(claireIdentifier);
		this.buffer.append(".unknownEntities := ");
		this.buffer.append(this.getListPrefix());
		this.buffer.append(temporaryBuffer.toString());
		this.buffer.append(this.getListSuffix());
		this.buffer.append(")\n");

		// I clean up a little bit...

		this.listOfAggregations.clear();
		this.listOfAssociations.clear();
		this.listOfCompositions.clear();
		this.listOfContainerAggregations.clear();
		this.listOfContainerCompositions.clear();
		this.listOfCreations.clear();
		this.listOfUses.clear();
	}
	protected String getListDeclaration() {
		return "Entity[]";
	}
	protected String getListOfListPrefix() {
		return "array!(list(";
	}
	protected String getListOfListSuffix() {
		return "), Entity[])";
	}
	protected String getListPrefix() {
		return "array!(list(";
	}
	protected String getListSuffix() {
		return "), Entity)";
	}
	public String getName() {
		return "PtidejSolver 2 custom domain";
	}
	public Object getResult() {
		return this.buffer.toString();
	}
	public void open(final IAbstractLevelModel p) {
		this.open((IAbstractModel) p);
	}
	private void open(final IAbstractModel p) {
		this.reset();
		this.pEntities = new IEntity[p.getNumberOfActors()];
		// Yann 2005/10/12: Iterator!
		// I have now an iterator able to iterate over a
		// specified type of constituent of a list.
		final Iterator iterator = p.getIteratorOnActors(IEntity.class);
		int i = 0;
		while (iterator.hasNext()) {
			this.pEntities[i++] = (IEntity) iterator.next();
		}
	}
	public void open(final IClass p) {
	}
	public void open(final IConstructor p) {
	}
	public void open(final IDelegatingMethod p) {
		// Yann 2004/08/07: Associations!
		// (In the plane between Seoul and Vancouver...)
		// The association relationships induced by a method are
		// taken care of by the creator, not the visitor!
		//	if (this.belongsToDomain(p.getReturnType())) {
		//		String pEntityName =
		//			PtidejSolverDomainGenerator.convertToClaireIdentifier(
		//				p.getReturnType());
		//
		//		if (!this.listOfAssociations.contains(pEntityName)) {
		//			this.listOfAssociations.add(pEntityName);
		//		}
		//	}
	}
	public void open(final IDesignMotif p) {
		this.open((IAbstractModel) p);
	}
	public void open(final IGetter p) {}
	public void open(final IGhost p) {
	}
	public void open(final IInterface p) {
	}
	public void open(final IMemberClass p) {
	}
	public void open(final IMemberGhost p) {
	}
	public void open(final IMemberInterface p) {
	}
	public void open(final IMethod p) {
		// Yann 2004/08/07: Associations!
		// (In the plane between Seoul and Vancouver...)
		// The association relationships induced by a method are
		// taken care of by the creator, not the visitor!
		//	if (this.belongsToDomain(p.getReturnType())) {
		//		String pEntityName =
		//			PtidejSolverDomainGenerator.convertToClaireIdentifier(
		//				p.getReturnType());
		//
		//		if (!this.listOfAssociations.contains(pEntityName)) {
		//			this.listOfAssociations.add(pEntityName);
		//		}
		//	}
	}
	public void open(final IPackage p) {
	}
	public void open(final ISetter p) {}
	public void reset() {
		this.buffer.setLength(0);
	}
	public void visit(final IAggregation p) {
		final String pEntityName =
			PtidejSolverDomainGenerator.convertToClaireIdentifier(
				p.getTargetActor().getName());

		if (!this.listOfAggregations.contains(pEntityName)) {
			this.listOfAggregations.add(pEntityName);
		}
	}
	public void visit(final IAssociation p) {
		final String pEntityName =
			PtidejSolverDomainGenerator.convertToClaireIdentifier(
				p.getTargetActor().getName());

		if (!this.listOfAssociations.contains(pEntityName)) {
			this.listOfAssociations.add(pEntityName);
		}
	}
	public void visit(final IComposition p) {
		final String pEntityName =
			PtidejSolverDomainGenerator.convertToClaireIdentifier(
				p.getTargetActor().getName());

		if (!this.listOfCompositions.contains(pEntityName)) {
			this.listOfCompositions.add(pEntityName);
			// Yann 2002/09/11
			// I must also add the composed entities
			// to the list of known entities.
			// Yann 2002/10/05: Why?
			//	this.listOfUses.add(pEntityName);
		}
	}
	public void visit(final IContainerAggregation p) {
		final String pEntityName =
			PtidejSolverDomainGenerator.convertToClaireIdentifier(
				p.getTargetActor().getName());

		if (!this.listOfContainerAggregations.contains(pEntityName)) {
			this.listOfContainerAggregations.add(pEntityName);
		}
	}
	public void visit(final IContainerComposition p) {
		final String pEntityName =
			PtidejSolverDomainGenerator.convertToClaireIdentifier(
				p.getTargetActor().getName());

		if (!this.listOfContainerCompositions.contains(pEntityName)) {
			this.listOfContainerCompositions.add(pEntityName);
			// Yann 2008/09/11
			// I must also add the composed entities
			// to the list of known entities.
			// Yann 2002/10/05: Why?
			//	this.listOfUses.add(pEntityName);
		}
	}
	public void visit(final ICreation p) {
		final String pEntityName =
			PtidejSolverDomainGenerator.convertToClaireIdentifier(
				p.getTargetActor().getName());

		if (!this.listOfCreations.contains(pEntityName)) {
			this.listOfCreations.add(pEntityName);
		}
	}
	public void visit(final IField p) {
		if (this.belongsToDomain(p.getType())) {
			String pEntityName =
				PtidejSolverDomainGenerator.convertToClaireIdentifier(
					p.getType());

			if (!this.listOfAssociations.contains(pEntityName)) {
				this.listOfAssociations.add(pEntityName);
			}
		}
	}
	public void visit(final IMethodInvocation aMethodInvocation) {
	}
	public void visit(final IParameter p) {
		// Yann 2004/08/07: Associations!
		// (In the plane between Seoul and Vancouver...)
		// The association relationships induced by a method are
		// taken care of by the creator, not the visitor!
		//	if (this.belongsToDomain(p.getType())) {
		//		String pEntityName =
		//			PtidejSolverDomainGenerator.convertToClaireIdentifier(
		//				p.getType());
		//
		//		if (!this.listOfAssociations.contains(pEntityName)) {
		//			this.listOfAssociations.add(pEntityName);
		//		}
		//	}
	}
	public void visit(final IUseRelationship p) {
		final String pEntityName =
			PtidejSolverDomainGenerator.convertToClaireIdentifier(
				p.getTargetActor().getName());

		if (!this.listOfUses.contains(pEntityName)) {
			this.listOfUses.add(pEntityName);
		}
	}
}